***************************
KNIGHTS OF THE OLD REPUBLIC
***************************

Title: Realistic Visual Effects
Author: Shem
Date Released: 5/21/08

Description: One thing I didn�t like about KOTOR was how they put in some visual effects that 
didn�t seem to fit in.  Like how all of a sudden there is a yellow energy blade on your Master 
Power Attacks even when you have a sword for some reason.  Possible how your hands will glow 
using the Master Critical Strike or Master Flurry attacks.  Maybe it�s how my screen would go 
all blurry when running around using Force Speed.

This mod eliminates things like that and many effects I didn�t think were necessary when playing 
KOTOR.  I made this mod for myself about a year ago, so I forget some of the things I have 
eliminated.  I suppose you�ll just have to find out what they are when installing this mod.  
Remember this is based on my vision on how I think it should be played.

Instructions: The TSL Patcher will be used to make these changes.  Most people won�t need to use 
the TSL Patcher because of you won�t have a visualeffects.2da file in your override folder, but 
in case you do and you want the changes already in there, I used the Patcher to keep it compatible.

THIS MODIFICATION IS NOT MADE, DISTRIBUTED, OR SUPPORTED BY BIOWARE, OR LUCASARTS ENTERTAINMENT 
COMPANY LLC. ELEMENTS TM & � LUCASARTS ENTERTAINMENT COMPANY LLC AND/OR ITS LICENSORS.
