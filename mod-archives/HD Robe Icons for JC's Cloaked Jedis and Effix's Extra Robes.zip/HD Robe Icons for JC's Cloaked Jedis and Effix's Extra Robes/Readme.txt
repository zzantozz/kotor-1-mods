As I'm sure many of you, I enjoy playing Kotor with JC's Cloaked Jedi Mod. Unfortunately, compared to the quality of my other icons after installing some of the other excellent icon mods, the robe mod makes the icons look pretty poor in comparison. This mod attempts to fix that by providing high quality icons for those mods. 
Since I also like playing with Effix's Extra Robes, I added icons for that mod as well. 




Installation

---------------------------------------------------------

Make sure you've installed your Robe mods first then within this mod browse to the directories of the mods you've installed and drag and drop those files into your Kotor's installation Override directory. Overwrite files once prompted.