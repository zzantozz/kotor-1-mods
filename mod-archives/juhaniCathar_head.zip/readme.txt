======================================
Knights of the Old Republic Juhani MOD
======================================

author:  miro42
email:  miro3_14@hotmail.com
website:  miro42.deviantart.com
name:  Cathar Juhani
credits (thanks):  Trex for his awesome tutorial and everyone at Holowan Labs.  Because there are too many to name, thanks for all the great tools out there!  For an actual list of programs and tools that I used, check out the little tutorial.  Of course, thanks go to Bioware and LucasArts for bringing KOTOR to life. 

filename:  juhaniCathar_head.zip
file size:  183KB (435kb unzipped)
date released:  18 Feb 2009

description:  For those of you who remember Star Wars pre-prequel, you might remember the old
Dark Horse comics series 'Tales of the Jedi'.  From this series one of my favorite characters
was Sylvar, the Cathar.  So when I found out that KOTOR had a Cathar I was psyched.  Of course
then I actually saw Juhani and I was quite dissapointed to find that she looked nothing like a
Cathar should.  She didn't even have any hair!  This mod gives Juhani an actual cat like
appearance (based more off of the 'Redemption' arc than the older ones) with a different nose, bigger ears, and a squatter, but (in my opinion) cuter face. 
I've also retextured her head so it looks a little bit nicer.

installation:  Extract contents of the zip file.  Place the .mdl, .mdx, and .tga files into override (x:Program Files\LucasArts\SWKOTOR by default).  Start KOTOR!  How easy is that?!

uninstallation (is that a word?):  delete the .mdl, .mdx, and .tga files from the override.

notes:  This is my first ever mod and I would like to think that there are no problems with it.  However, computers are computers and I'm sure someone will have a problem.  If this is the case please email me and I'll look into figuring out the problem.  However, since this is my first mod I don't really know what else I can do as my skills are all but nill.  So, try redownloading and reinstalling and see if that works.  Good luck, and have fun!

permissions:  If you wish to use this for anything but personal use, send me an email and I'm sure I'll give you permission to use it however you like.

THIS MODIFICATION IS PROVIDED AS-IS AND IS NOT SUPPORTED BY BIOWARE/OBSIDIAN ENTERTAINMENT OR LUCASARTS OR ANY LICENSERS/SPONSORS OF THE MENTIONED COMPANIES. USE OF THIS FILE IS AT YOUR OWN RISK AND THE ABOVE MENTIONED COMPANIES OR THE AUTHOR IS NOT RESPONSIBLE FOR ANY DAMAGE CAUSED TO YOUR COMPUTER FOR THE USAGE OF THIS FILE.
