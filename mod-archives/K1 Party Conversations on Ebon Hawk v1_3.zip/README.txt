PARTY CONVERSATIONS ON EBON HAWK
For Star Wars: Knights of the Old Republic
By WildKarrde
-------------------------------------------------------------------

KOTOR features several conversations between party members which occur as you explore the various planets.  Unfortunately, it is easy to miss some of them if you rarely use certain combinations of characters, such as Carth with Canderous or Bastila with Jolee.  This mod moves these conversations to the Ebon Hawk and the Taris apartment hideout similar to KOTOR 2, guaranteeing that you can see nearly every conversation in a single playthrough.  Conversations which directly refer to Taris are set to take place while you are still there, while the remaining conversations will occur in semi-random order up until (or possibly slightly after) the Leviathan sequence.  Aside from the change in location, I have also made some slight edits to the conversations themselves, mainly relating to the timing of character animations.

By default, conversations will also still occur on the various planets like in the vanilla game.  They will only occur at the Ebon Hawk/hideout as required to catch you up on any that you may have missed.  I have also provided an option to make the conversations happen only at the Ebon Hawk/hideout, never out on the planets.

Thank you for downloading, and I hope you enjoy this mod!

-------------------------------------------------------------------
INSTALLATION

Run INSTALL.exe and select either the standard version or the KOTOR 1 Community Patch compatible version.  If you would like the conversations to take place only at the Ebon Hawk/hideout, run INSTALL.exe again and select "OPTION:  Ebon Hawk/Hideout Only".  If you have other mods installed, it is normal to see warnings that ebo_m12aa.mod and/or tar_m02af.mod already exist and have been skipped.

-------------------------------------------------------------------
COMPATIBILITY
This mod is compatible with the KOTOR 1 Community Patch (K1CP) and incorporates its fixes to k_pebn_pophawk.ncs.  It has not been tested with the KOTOR 1 Restoration (K1R), but in theory it should be compatible.  It is not compatible with any mods that edit k_pebn_pophawk.ncs or banter.dlg.

For best results, install this mod after K1CP, K1R, or any other mods that make significant edits to the Ebon Hawk interior or to the Taris apartment hideout.

-------------------------------------------------------------------
CREDITS
NWNSSCOMP by Torlack and tk102
DeNCS by JdNoa and Dashus
K-GFF by tk102
DLGEditor by tk102
TSL Patcher by stoffe and Fair Strides
ERFEdit by stoffe and Fair Strides
Kotor Tool by Fred Tetra

This mod includes fixes to k_pebn_pophawk.nss which were developed by the K1CP team.

This mod was inspired by the following mod request thread on Deadly Stream:  https://deadlystream.com/topic/5684-party-member-conversations-in-apartment-and-ebon-hawk-k1/.  Thanks to everyone who participated in the original thread for their discussion, which provided a major source of inspiration.

-------------------------------------------------------------------
VERSION HISTORY
1.0   - Initial Release
1.1   - Revised installation process and options
      - Revised the walk scripts in the Mission/Bastila conversation so that they do not need to be compiled during installation
      - Adjusted the camera angles the Mission/Bastila conversation
      - Adjusted the conditions for determining when conversations play before and after the Leviathan sequence
      - Added an extended fade to hide the party fading out and reappearing when entering the Ebon Hawk or Taris apartment
      - Revised implementation of edits to tar02_bastvision.dlg to reduce incompatibilities with other mods that edit the same file
        (i.e. K1CP 1.10).
      - Cleaned up and clarified comments in the script source files
1.2   - Added additional conditions to the Taris apartment entry script to prevent a rare issue where the vanilla conversation after
        "rescuing" Bastila did not occur.  Thanks to PoopaPapaPalpatine for reporting the issue and testing the fix.
1.2.1 - Added additional conditions to the Ebon Hawk entry script to prevent a rare issue where the cutscenes before landing
        on Dantooine for the first time did not occur and the game softlocked.  Thanks to CapitaineSpoque for reporting the issue and
        testing the fix.
1.3 - Adjusted camera angles and walk timing for the Mission/Bastila conversation on the Ebon Hawk to improve camera behavior.

-------------------------------------------------------------------
DISCLAIMER AND PERMISSIONS
This modification is provided as-is and is not supported by Disney, Lucasarts, or Bioware.  Use at your own risk.  The author shall not be held responsible for damage to your game installation, computer, or saved games resulting from the use of this mod.

This mod shall not be reposted, in whole or in part, on any sites other than Deadly Stream without the author's permission.  Assets from this mod shall not be redistributed in other modifications without the author's permission.