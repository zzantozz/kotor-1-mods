Korriban Academy Workbench v2.0 by Darth InSidious
--------------------------------------------------

Update: 15/5/2010
-----------------

Having been informed of a bug which caused problems with the workbench on the Ebon Hawk, 
I have overhauled the mod to eliminate this issue. :)

Description
------------

A little while ago it struck me - The Dantooine Jedi academy has a workbench,
but the Korriban Academy didn't, which can be very inconvenient. In fact, there
wasn't one on all Korriban.

This mod fixes all that! Now there is a workbench in the little room which leads
to the Valley of the Dark Lords. It's just on the left as you come in.

The only mod conflict that there might be is if someone else's mod modifies Master
Uthar's dialogue.

Installation
------------
IF YOU HAVE REDHAWKE'S CONSTRUCTION BENCH MOD INSTALLED:

Put the following files in your Override folder:

di_spwb_01.ncs
di_wb01.uti
kor35_utharwynn.dlg

IF YOU DO NOT HAVE REDHAWKE'S CONSTRUCTION BENCH MOD INSTALLED:

Put the following files in your Override folder:

di_spwb_01.ncs
di_wb01.uti
kor35_utharwynn.dlg
k_pebo_upgrade.ncs

Uninstallation
--------------

Take the above-mentioned files out of your Override folder again. 
However, to remove the effects of the mod, you will need to start a new game.

Thanks
------

Many thanks to the kind folk of Holowan Labs, to whom I am eternally indebted.

Disclaimer
---------
Salk, for pointing out to me bugs in the mod, and acting as beta-tester. :)
LucasArts and Bioware own all the copyrights etc. It all belongs to them.
Also, if you're going to re-use this in a mod and upload that mod somewhere,
it'd be nice if my permission was asked. Likewise if you intend to upload this mod
anywhere other than where it is now.