~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
� Gaffi Stick Improvement ReadMe
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
AUTHOR: Fallen Guardian
NAME: Gaffi Stick Improvement
TYPE: Modification
VERSION: Full Release
SIZE - Unzipped: 10.3 Megabytes, Zipped:  7.18 Megabytes
DATE CREATED: May 5, 2012
DATE RELEASED: May 8, 2013
RELEASE THREADS: 2

~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
� DESCRIPTION
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
This mod improves the texture of the original gaffi stick, to a high quality, 1024X1024 texture. Also, it gives the Sand People chieftain a unique gaffi stick that also is a high quality, 1024X1024 texture.
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
� INSTALLATION
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
An installation which involves the TSL Patcher has been made ready for your use and is the simplest and easiest way to carry out installation. 
If you wish, for whatever reason, to not use TSL Patcher it will require you to manually copy and paste files from the tslpatchdata folder into the specific folders they need to be placed in.

Note: I am not responsible for any incompatibility issues that may arise (whether the mod was installed with TSLPatcher or manually) from the use of this mod in conjunction with other mods. Though I will do my best to fix any legitimate bugs.
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
� TSL PATCHER INSTALLATION
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
1) Double click Gaffi Stick Improvement.exe found in the main directory of the Gaffi Stick Improvement Folder.
2) Click the button labeled "Install Mod".
3) Click yes to the box that'll pop up... if you wish to proceed with installation.
4) Watch as all the little file names and progress reports scroll by and wait until the installer is complete.
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
� MANUAL INSTALLATION
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Pretty simple actually � pull any and all files out of the tslpatchdata folder that are not labeled either �changes.ini� or �info.rtf� and put them into your override folder.

~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
� KNOWN BUGS
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

None.

~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
� BUG REPORTING
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
There are 3 ways to report bugs. 1: Post your issues in the release thread found in the Taris Upper City Emporium (The thread will be named Gaffi Stick Improvement). 2: Post your issues in the release thread found in the Deadly Stream Mod Releases section (The thread will be named Gaffi Stick Improvement). 3: PM your issues to me (Fallen Guardian) at either Deadly Stream or Lucas Forums.


TO REPORT THROUGH TARIS UPPER CITY EMPORIUM

1) Go to the Taris Upper City Emporium section of the Knights of the Old Republic branch of LucasForums "http://www.lucasforums.com/forumdisplay.php?f=645" and either create an account or login to your existing one.
2) Find the thread called "Gaffi Stick Improvement".
3) If the bug has not been reported already, post a VERY DETAILED description of what is occurring in your game. I will likely report back to you within a week.

TO REPORT THROUGH THE DEADLY STREAM MOD RELEASES SECTION

1) Go to the Mod Releases section in the Knights of the Old Republic modding branch of Deadly Stream "http://deadlystream.com/forum/forum/17-mod-releases/" and either create an account or login to your existing one.
2) Find the thread called "Gaffi Stick Improvement".
3) If the bug has not been reported already, post a VERY DETAILED description of what is occurring in your game. I will likely report back to you within a week.

TO REPORT THROUGH PM

1) Go to DeadlyStream (http://deadlystream.com/) or LucasForums (http://www.lucasforums.com/), sign into/create your account, and search for the user Fallen Guardian (http://deadlystream.com/forum/user/8932-fallen-guardian/) or (http://www.lucasforums.com/member.php?u=167390)
2) Send me a private message with a VERY DETAILED description of what is occurring in your game. I will likely report back to you within a week.


~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
� REDISTRIBUTION
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
The Gaffi Stick Improvement mod may NOT be redistributed in any way without the explicit permission of the author (Fallen Guardian) and the proper credit given.

~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
� LEGAL
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
THIS MODIFICATION IS PROVIDED AS-IS AND IS NOT SUPPORTED BY BIOWARE CORP/OBSIDIAN ENTERTAINMENT OR LUCASARTS OR ANY LICENSORS/SPONSORS OF THE AFOREMENTIONED COMPANIES. USE OF THIS FILE IS AT YOUR OWN RISK AND THE AFOREMENTIONED COMPANIES OR THE AUTHOR(S) ARE NOT RESPONSIBLE FOR ANY DAMAGE CAUSED TO YOUR COMPUTER FOR THE USAGE OF THIS FILE.
