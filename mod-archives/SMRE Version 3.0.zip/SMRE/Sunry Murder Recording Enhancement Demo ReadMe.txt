~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
� Sunry Murder Recording Enhancement Demo ReadMe
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
NAME: Sunry Murder Recording Enhancement
TYPE: Added Content
VERSION: 3.0
SIZE - Unzipped: 2.97 Megabytes, Zipped:  796 Kilobytes
DATE RELEASED: August 3, 2013
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
� DESCRIPTION
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
In the vanilla version of the game there was a quest on Manaan which inolved you becoming a lawyer for an ex-Republic soldier who had supposedly murdered a Sith. This, if you followed it far enough, would eventually lead you to investigating around the embassies of both the Republic and the Sith. When you found some evidence, it was presented in the form of text, though referred to as a video by said text. I have taken this text and turned it into a video (a cutscene) showing the events which the text described.
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
� VERSION 2.0 CHANGES
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Fixed the TSL Patcher installation so it no longer causes the game to crash when entering manm26ae. Now both the manual installation and the TSL Patcher installation work.
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
� VERSION 3.0 CHANGES
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Added in needed files for the recording to take place - thanks to Achawks123 for first identifying the bug.
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
� INSTALLATION
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
An installation which involved the TSL Patcher has been made ready for your use and is the simplest and easiest way to carry out installation. 
If you wish, for whatever reason, to not use TSL Patcher it will require you to manually copy and paste files from the TSLPatchdata folder into the specific folders they need to be placed in.


Note: I am not responsible for any incompatibility issues that may arise from the use of this mod in conjunction with other mods. (Though I'll help you try and sort them out, if you tell me about them.)
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
� TSL PATCHER INSTALLATION
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
1) Double click SMRE Installer.exe found in the main directory of the Sunry Murder Recording Enhancement folder.
2) Click the button labeled Install Mod.
3) Click yes to the box that'll pop up... if you wish to proceed with installation.
4) Watch as all the little file names and progress reports scroll by and wait until the installer is complete.

(IMPORTANT! If you encounter error while running the TSLPatcher saying that manm26ae.mod already exists, DO NOT worry. This just means a little insurance policy I had in place wasn't needed.)
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
� MANUAL INSTALLATION
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
1) Open up the folder titled "Manual Installation".
2) Just take the one file in there (manm26ae.MOD) and put it in the Modules folder, found in the SWKotOR main directory.

(I TAKE NO RESPONSIBILITY FOR ERRORS MADE WHILE MANUALLY INSTALLING THIS MOD)
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
� KNOWN BUGS
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
- Rarely Elassa will turn around right when she shouldn't
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
� BUG REPORTING
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
There are 3 ways to report bugs. 1: Post your issues in the Taris Upper City Emporium Release Thread. 2: Post your issues in the Deadly Stream Release Thread. 3: PM your issues to me (Fallen Guardian) at Deadlystream or Lucas Forums.


TO REPORT THROUGH TARIS UPPER CITY EMPORIUM

1) Go to the Taris Upper City Emporium section of the Knights of the Old Republic branch of LucasForums (http://www.lucasforums.com/forumdisplay.php?f=645) and either create an account or login to your existing one.
2) Find the thread called "Sunry Murder Recording Enhancement".
3) If the bug has not been reported already, post a VERY DETAILED description of what is occurring in your game. I will report back to you in a week. If I don't, feel free to try the 3rd method of reporting bugs, which is private messaging me.

TO REPORT THROUGH DEADLY STREAM

1) Go to the Mod Releases Section of the Knights of the Old Republic branch of Deadly Stream (http://deadlystream.com/forum/forum/17-mod-releases/) and either create an account or login to your existing one.
2) Find the thread called "Sunry Murder Recording Enhancement".
3) If the bug has not been reported already, post a VERY DETAILED description of what is occurring in your game. I will report back to you in a week. If I don't, feel free to try the 3rd method of reporting bugs, which is private messaging me.


TO REPORT THROUGH PM

1) Go to Deadly Stream (http://deadlystream.com/) or Lucas Forums (http://www.lucasforums.com/) and search for the user Fallen Guardian. Lucas Forums: http://www.lucasforums.com/member.php?u=167390, Deadly Stream: http://deadlystream.com/forum/user/8932-fallen-guardian/
2) Send me a private message with a VERY DETAILED description of what is occurring in your game. I will likely report back to you within a week. If I don't report back, well, you can wait a bit. If you've waited for a year, get over it. I'm probably never going to reply if I don't reply wihtin a year.
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
� SPECIAL THANKS
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
To the tool creators of the community

	~ Kotor Tool.....................A VERY special thanks to Fred Tetra
	~ K-GFF GFF Editor/DLGEditor.....tk102
        ~ ERF Editor/TSLPatcher..........stoffe

Also thanks to everyone over at Holowan Labs for helping me whenever I have problems with modding.
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
� REDISTRIBUTION
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
This mod may NOT be redistributed in any way without the explicit permission of myself (Fallen Guardian) and the proper credit given to me within the ReadMe.
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
� LEGAL
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
THIS MODIFICATION IS PROVIDED AS-IS AND IS NOT SUPPORTED BY BIOWARE CORP/OBSIDIAN ENTERTAINMENT OR LUCASARTS OR ANY LICENSERS/SPONSORS OF THE AFOREMENTIONED COMPANIES. USE OF THIS FILE IS AT YOUR OWN RISK AND THE AFOREMENTIONED COMPANIES AND THE AUTHORS ARE NOT RESPONSIBLE FOR ANY DAMAGE CAUSED TO YOUR COMPUTER FOR THE USAGE OF THIS FILE.