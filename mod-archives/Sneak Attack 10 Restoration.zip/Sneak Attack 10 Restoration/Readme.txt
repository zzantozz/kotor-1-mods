A Mod for Star Wars Knights of The Old Republic
Author: N-DReW25
Release Date: 12.07.2017
 
Installation:
Double Click the TSLPatcher.exe and let it do its magic
 
Uninstallation:
When the TSLPatcher installs the mod correctly it generates a backups folder within the Simple Weapons Feat Restoration folder that contains the TSLPatcher. Open the backups folder and copy the 
"feat.2da" to the override folder overriding the Simple Weapons Feat Restoration files
 
Description:
In Kotor there are 9 sneak attack feats that the scoundrel can get, however, looking into the game files there is a 10nth sneak attack feat that appears to be unused. 
It is only avaliable to the scoundrel (Mission and the scoundral player character) at level 19. Sneak Attack 10 adds 10-60 points of extra damage to attacks when the 
target can't respond to the attacker, making it more powerful than sneak attack 9's 9-54 points of extra damage.


Known Bugs:
None known. If you find any report it to me either by commenting it in the release thread of via a PM
 
Incompatibilities:
Should be compatiable with most mods
 
If you spot an incompatibility please alert me
 
Permissions:
Do NOT claim credit for this mod and do not use assets from this mod without my permission
 
Thanks:
The entire K1R team for making K1R and restoring most of the cut content
Bioware for such an amazing game
Fred Tetra for Kotor Tool and everyone who downloads the mod.
 
Legal:
THIS MODIFICATION IS NOT SUPPORTED BY BIOWARE/OBSIDIAN ENTERTAINMENT, LUCASARTS, DISNEY OR ANY LICENSERS/SPONSORS OF THE MENTIONED COMPANIES. USE OF THIS FILE IS AT YOUR OWN RISK AND THE ABOVE MENTIONED COMPANIES OR THE AUTHOR IS NOT RESPONSIBLE FOR ANY DAMAGE CAUSED TO YOUR COMPUTER FOR THE USAGE OF THIS FILE.