Heyorange's Sith Uniform Reformation
A Mod for Star Wars Knights of The Old Republic
Author: Heyorange (aka Pataschka)
Version: 1.0

Description:
This mod is a bunch of reskins of the sith officer uniforms. Different uniforms with different rank insignias were given to different officers throughout the game to give a bit more realistic look. 
Aside from that, the uniform of the Admiral Saul Karath was changed and a new reskin for sith students was added.

The Mod is devided into 3 parts:
1. Heyorange's Sith Uniform Reformation - the main part of the mod
2. Sith Students + Czerka on Korriban fix - reskin of the standart sith uniforms for Korriban sith students and fix for Czerka workers on Korriban to have correct uniforms
3. K1R fix - A reskin of the sith uniform for the added wounded officer on the Leviathan by the K1R modification

INSTALLATION:
THis mod doesn't have TSLPatcher so to install it copy desired files to your Override folder:
- If you are using mods such as "Back in Black" or any other mod that changes the uniforms of the sith students and fixes Czerka workers then copy only files from "Heyorange's Sith Uniform Reformation" folder to your Override folder
- If you don't have any mods affecting the appearance of the sith students and czerka officers than copy the files both from "Heyorange's Sith Uniform Reformation" and "Sith Students + Czerka on Korriban fix" folders to your Override folder
- If you are using K1R modification than copy the files from all 3 folders to your Override folder

COMPABILITY:
Would be incompatible with any mods that change the model of the sith officers. Should work both with vanilla game and K1R.
 
PERMISSIONS:
I am giving my permission to use any part of this mod to anyone as long as I am credited as the original author

THIS MOD IS NOT SUPPORTED BY LUCASARTS OR BIOWARE. USE THIS FILE AT YOUR OWN RISK. 
NEITHER THE AUTHOR OF THIS MOD NOR THE COMPANIES MENTIONED ABOVE ARE RESPONSIBLE FOR ANY DAMAGE TO YOUR COMPUTER WHEN USING THIS FILE.