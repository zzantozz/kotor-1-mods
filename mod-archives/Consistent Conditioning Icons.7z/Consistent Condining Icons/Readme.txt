Consistent Conditioning Icons
by Sdub

Version:
1.0

Description:	
I was looking at icons today and noticed the first conditioning icon just didn’t match the others. I sought to change that. The icon names are very different so I can only guess that maybe early in development they were separate feats.

I also rotated the Master Conditioning icon to be vertical

Installation:	
Place Icons in Override folder

Uninstallation:	
Remove files from Override Folder

Compatibility:	
There should be no issues

K1R Compatible:	
Yes

Tools Used:
GIMP
KOTOR Tool 
Big thanks to the KOTOR Discord and Deadlystream Discord
