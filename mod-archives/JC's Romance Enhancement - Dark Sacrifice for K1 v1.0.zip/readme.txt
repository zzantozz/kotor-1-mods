================================================================================

    JC's Romance Enhancement:
    Dark Sacrifice for K1        v1.0

================================================================================

						by JCarter426

================================================================================
    TABLE OF CONTENTS
================================================================================

1.  Summary
2.  Installation
3.  Uninstallation
4.  Compatibility
5.  Permissions
6.  Credits
7.  Disclaimers
8.  Donations
9.  Contact



================================================================================
1.  SUMMARY
================================================================================

This mod uses a mix of new and unused content to restore an alternate ending
that was cut from the game. With this mod, players who have romanced Carth and
fallen to the dark side will be presented with the option to seek redemption in
a new ending distinct from the base game light side and dark side endings.

Choosing the dialogue option "No, let him speak. I want to hear what he has to
say." in a conversation with Carth at the end of the game will lead to the
restored sequence. The player will then have the option to choose the base game
dark side ending or the new ending.



================================================================================
2.  INSTALLATION
================================================================================

1. Extract files from the downloaded archive.
2. Run Install.exe.
3. Click "Install Mod" and select your game directory (default name SWKOTOR).



================================================================================
3.  UNINSTALLATION
================================================================================

1. Remove the following files:
   - modules/stunt_sacrifice.mod
   - streammusic/dark_sacrifice.wav
2. Replace the following files with backups if necessary, otherwise remove them:
   - modules/sta_m45aa.mod
   - modules/STUNT_56a.mod



================================================================================
4.  COMPATIBILITY
================================================================================

This mod is compatible with the KOTOR 1 Community Patch. This mod should be
installed after K1CP if you wish to use both.

This mod is compatible with Leilukin's Carth Onasi and Male PC Romance.

This mod is compatible with my other Romance Enhancement mods Bioromantic
Bastila and Pan-Galactic Flirting.



================================================================================
5.  PERMISSIONS
================================================================================

Mod:            JC's Romance Enhancement for K1
--------------------------------------------------------------------------------
Mod Author:     JCarter426
---------------
Game:           Star Wars: Knights of the Old Republic
--------------------------------------------------------------------------------
Attribution     "Romance Enhancement JCarter426" or "uses JC's Romance
Preference:     Enhancement" or some other reasonable phrasing.
--------------------------------------------------------------------------------

Attribution Only License (AOL)

* You've got mods! *

The creator of this mod has authorized the contents of this mod for public use.
Other modders are free to use and edit materials from this mod and include them
in other mods. This license applies to everyone equally and no further explicit
permission from the original mod creator is required, provided the terms of this
are followed.

- The user must provide clear attribution for the source and creator(s) of these
  materials, following the specified attribution preference. The file that
  contains this attribution must be included along with all the other mod
  contents.
  (For example, crediting the original mod creator in your mod's description on
  a website, but not in any file someone would actually download, would be a
  violation.)

- The user must include any additional credits as indicated.

- This license applies only for the use of these materials in other mods (i.e. a
  form of software accessed within a video game). This license does not grant
  the user unlimited power to distribute these contents, edited or unedited,
  even if attribution is granted. These materials are being offered to encourage
  the creation of new mods that alter the game experience. 
  (For example, distributing these materials as a mod resource on another
  website, or uploading the entirety of the mod as a "new" mod without really
  changing anything, would not be in the spirit of this license.)

- Where appropriate, it would be nice to provide a link to the original mod and/
  or tag the original mod creator. However, this is not mandated. This is just a
  polite suggestion.



================================================================================
6.  CREDITS
================================================================================

KOTOR Tool          Fred Tetra
TSLPatcher          stoffe & Fair Strides
DeNCS               JdNoa & Dashus
DLGEditor           tk102
ERFEdit             stoffe & Fair Strides
K-GFF               tk102
KOTORMax & MDLEdit  bead-v
NWMax               Joco
NWNSSCOMP           Torlack, stoffe, & tk102
xoreos tools        xoreos team
                    https://xoreos.org/

with thanks to:
- JdNoa for creating the Alternate DS Female Romance Ending mod that inspired
  this mod
- Sniggles for conducting thorough testing
- Leilukin for providing valuable save files for testing
- DarthParametric for help troubleshooting the final cutscene



================================================================================
7.  DISCLAIMERS
================================================================================

THIS GAME MODIFICATION IS NOT SUPPORTED BY OR ROMANTICALLY INVOLVED WITH CARTH
ONASI, <FULLNAME>, LUCASARTS, OR BIOWARE. OTHER ENDINGS ARE AVAILABLE.



================================================================================
8.  DONATIONS
================================================================================

If you enjoy my mods and would like to show your support in a monetary manner,
you may do so via PayPal with the donation link below.

http://www.paypal.me/carterunited

For various legal and ethical reasons, this is entirely optional and is not a
requirement to downloading or using any of my mods. I also do not create
specific mods for hire.

I make mods as a hobby and will most likely do so regardless of any donations or
lack thereof, but modding does take up a lot of my time and every bit helps.



================================================================================
9.  CONTACT
================================================================================

Questions? Problems? Suggestions? Something else?

Email me at kotor.hexATgmailDOTcom or PM me on Deadly Stream or wherever else
you can find me.