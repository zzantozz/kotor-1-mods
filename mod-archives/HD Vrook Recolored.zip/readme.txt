				HD Vrook Recolored
				By Publicola


=============
Description
=============
I love Dark Hope's reskin for Jedi Master Vrook, 'HD Vrook'. However, I thought that the mod's changes to his skin tone -- from warm 
and healthy to pale and decidedly old -- fit far better for his appearance in KOTOR 2.

With her permission, I took Dark Hope's HD Vrook as a base and added a bit of warmth to Vrook's skin tone, to suit his appearance 
in KOTOR 1.


=============
Permissions
============
You may modify my mod without credits or permission. Please credit the original author (Dark Hope) wherever possible.
This mod uses both the .txi file and the base .tga texture from HD Vrook by Dark Hope.


=============
Installation
=============
Download, extract, copy both files into your KOTOR 1 Override folder.


=============
To Uninstall
=============
Delete N_VrookH.tga and N_VrookH.txi from your Override folder.