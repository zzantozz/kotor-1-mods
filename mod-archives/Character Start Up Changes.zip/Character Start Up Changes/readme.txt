AUTHOR: jonathan7
EMAIL: Message me via lucas forums user name is jonathan7
NAME: Character Start Up Changes
CREDITS: Fred Tetra for the wonderful KotOR tool, all at Lucas Forums for the various Tutrials and Stoffe for TSLpatcher.

FILENAME: Character Start Up Changes
FILE SIZE: 725kb unzipped
DATE RELEASED: 12/12/2010

DESCRIPTION: This essentially changes the starting feats for the three classes and makes pretty much all the feats availible for the player to select for their individual PC. Personally it always bugged me that often my PC would end up with quite a few useless feats that she did not need. So what this does is delete all the preset feats for the classes and give you free selectable ones, the Soldiers have the most, then Scouts then Scoundrels; you have the same ammounts of feats as in the vanilla game but you are free to choose what you want. I think this does improve the RPG aspect of the game, be warned however to make sure you specialise in either melee weapons or some form of blaster, otherwise you won't be doing much in combat! The mod also changes Persuade into a class skill, so it's availible to all three classes, always struck me as silly that Bioware didn't do this, as the PC is the only charachter who can actually use Persuade, seemed unfair only one of the classes got it; but maybe thats just me. A couple of pre-set feats remain; for the Scout the Implant Feat 1, because the scount automatically gets them as the PC is leveled up. The scoundrel keeps Scoundrels luck for obvious reasons, not that its a selectable feat, but things like that and "uncanny dodge" I have left alone.

INSTALLATION INSTRUCTIONS:"Extract from the zip and then run the installer, simple enough!

COMMENTS: Enjoy!

BUGS: Should be none, may well require a little work to make compatible with other mods which edit these .2da's - Shem's extra feat mod spring to mind, but to be honest if you have that, then I don't see why your installing this :-p

PERMISSIONS: PM me at LF to discuss useage.This Mod should only be found at KotOR Files and
Lucas Files, please contact me if hosted elsewhere!

THIS MODIFICATION IS PROVIDED AS-IS AND IS NOT SUPPORTED BY BIOWARE/OBSIDIAN ENTERTAINMENT
OR LUCASARTS OR ANY LICENSERS/SPONSORS OF THE MENTIONED COMPANIES. USE OF THIS FILE IS AT
YOUR OWN RISK AND THE ABOVE MENTIONED COMPANIES OR THE AUTHOR IS NOT RESPONSIBLE FOR ANY
DAMAGE CAUSED TO YOUR COMPUTER FOR THE USAGE OF THIS FILE.