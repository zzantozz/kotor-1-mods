KOTOR DIALOGUE FIXES v5.1 by Salk
---------------------------------

This modification corrects some typos, VOs inconsistencies and some punctuation problems found in the dialog.tlk file (patched with the official 1.03 patch by Lucasarts). I am the only one who worked on this modification and I am fully aware of the very likely presence of more typos that I might have missed or never seen due to my in-game dialogue choices (prevalently light-sided). I'd be grateful to have people report (email: crimes73@gmail.com) new typos that escaped my attention. This mod can not be altered and distributed without my explicit authorization.



Installation
------------

Make a copy of the original dialog.tlk then overwrite the dialog.tlk with either the corrections-only version or the revised version, which includes the corrections and most of the changes found in the PC Response Moderation modification by Kainzorus Prime. Done.



Uninstallation
--------------

Just replace the dialog.tlk file with the one you backed up.



Compatibility
-------------

This mod should be installed just after having patched the game with Lucasarts 1.03 official patch. It is not compatible with any other mod that would overwrite the dialog.tlk file.




List of corrections made to 1.03 patched dialog.tlk file:
---------------------------------------------------------

around -> about
want step -> want to step
occular -> ocular
*Sigh* -> *sigh*
*Ahem* -> *ahem*
*Sniff* -> *sniff*
UpWorlder -> up-worlder
hidden Beks -> Hidden Beks
really the place -> really the best place
Same price as for the bounties -> way more than a bounty price
doing he -> doing when he
who's -> whose
palette -> palate
dark Jedi -> Dark Jedi
Okay you alien -> Right you alien
Hey, what's this? -> What's this?
...-> ... (added a blank space)
rehearsels -> rehearsals
one voiced-tongue -> one-voiced tongue
before by people -> by people before
Gammorean -> Gamorrean
won -> win
meet -> met
are is -> is
by looks -> by the looks
hands now -> hands by now
about anymore -> anymore about
enought -> enough
offworlder -> off-worlder
an all too -> on all too
a guards -> a guard
everrything -> everything
a bit enamored -> a little enamored
aqualish -> Aqualish
madclaw -> mad-claw
he doesn't need you taunting -> He doesn't need you taunting
premission -> permission
the first to the -> the first to fight the
eccenticities -> eccentricities
come one -> come on
the the -> the
promply -> promptly
Is is -> It is
as well the -> as well as the
here back -> back here
I see you that you -> I see that you
dead of -> dead or
compliment -> complement
become Malak's -> became Malak's

2.0 fixes:
----------

the Ajuur -> Ajuur
canyone -> canyon
on all -> on an all
We am -> We are
stood -> stood there
doing he picked -> doing when he picked
youself -> yourself
as you -> as you.
Well, There -> Well, there
to many -> so many
tempermental -> temperamental
Congradulations -> Congratulations
it's -> its
Freedon Nadd -> Ajunta Pall

3.0 fixes:
----------

undo attention -> undue attention
can over -> overcome
sorry father -> sorry, Father
blunt human -> blunt, human
who's mind -> whose mind
defendants -> defendant's
father -> Father
Your Father -> Your father
Mother -> mother
Mandalorain -> Mandalorian
your honor(s) -> your Honor(s)
darkside -> dark side
'' (single quote) -> "" (double quote)
Chanting -> chanting
Czerka Corp -> Czerka Corp.
corp -> Corp
meat-bag -> meatbag
projectile -> projectiles
gotta do.[R1] -> gotta do.
the are-> they are
something else![R1] -> something else!
dark path.[R1] -> dark path.
some toy![R1] -> some toy!
memroy -> memory
as it's communication -> as its communication
beastsl -> beasts
sesnsory -> sensory
Tais -> Taris
Interdicter -> Interdictor
woa as me -> woe is me
master" type -> master" type.
hinderance -> hindrance
perminently -> permanently
data-pad -> datapad
your Nurik -> Nurik

4.0 fixes:
----------

lifedebt -> life-debt
to path of -> to the path of
wisdom the Jedi -> wisdom of the Jedi
never mine -> never mind
work an organization -> work for an organization
modifiy -> modify
afficionados -> aficionados
fastet -> fastest
extend of -> extent of
conceed -> concede

5.0 fixes:
----------

merceneray -> mercenary
independant -> independent
investigaton -> investigation
recieved -> received
ignroes -> ignores
evironment -> environment
reaxed -> relaxed
shoud -> should
retuns -> returns
redemeed -> redeemed
abilites -> abilities
artifical -> artificial
impluses -> impulses
memer -> member
acess -> access
agreable -> agreeable
reagrding -> regarding
agrement -> agreement
occurence -> occurrence
went emissaries -> sent emissaries
undergound -> underground
metres -> meters
portait -> portrait
to to to -> to do
authorites -> authorities
promotor -> promoter
disrupter -> disruptor
entrie -> entire
salvaton -> salvation
moral -> morale
inteference -> interference
permium -> premium
cannister -> canister
targetting -> targeting
reprecussions -> repercussions
it's own -> its own
find my self -> find myself
I won't you questions -> I won't ask you questions
. Chuundar! -> , Chuundar!
Very well. here -> Very well. Here
vs. The Sith -> vs. the Sith
speak to me and when -> speak to me when
cannot draw anymore -> cannot draw any more 
cannot play anymore -> cannot play any more
jeporadize -> jeopardize
soceity -> society
Vulkar's -> Vulkars
though I hear -> though I heard
that may explain -> that might explain

5.1 fix:
--------

Reverted a change for a verb that was not a typo (to live with -> to leave with)

5.2 fix:
--------
should we wiped -> should be wiped (from PC Response Moderation)


CREDITS:
--------

Thanks to 134340Goat for spotting a few more typos (3.0 update)
Thanks to Gimmick5000, Kainzorus Prime and Ebnar for providing a number of corrections