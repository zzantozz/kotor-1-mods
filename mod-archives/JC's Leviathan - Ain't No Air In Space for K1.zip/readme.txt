================================================================================

    JC's Leviathan:
    Ain't No Air in Space for K1        v1.0

================================================================================

                                        by JCarter426

================================================================================
    TABLE OF CONTENTS
================================================================================

1.  Summary
2.  Installation
3.  Uninstallation
4.  Compatibility
5.  Permissions
6.  Credits
7.  Disclaimers
8.  Donations
9.  Contact



================================================================================
1.  SUMMARY
================================================================================

This mod restores an instant death event triggered by going to space without
a space suit.



================================================================================
2.  INSTALLATION
================================================================================

Automatic Installation (Recommended)
1. Extract files from the downloaded archive.
2. Run Install.exe.
3. Click "Install Mod" and select your game directory (default name SWKotOR).

Manual Installation
1. Extract files from the downloaded archive.
2. If you do not have an override folder, make one in your game directory
   (default name SWKotOR).
3. Copy k_plev_airouopn2.ncs to your override folder.



================================================================================
3.  UNINSTALLATION
================================================================================

From Automatic Installation
1. Replace the following file with backup if necessary, otherwise remove:
   - modules/lev_m40ad.mod

From Manual Installation
1. Remove the following file:
   - override/k_plev_airouopn2.ncs



================================================================================
4.  COMPATIBILITY
================================================================================

This mod is compatible with the KOTOR 1 Community Patch.

This mod is compatible with the KotOR 1 Restoration mod.



================================================================================
5.  PERMISSIONS
================================================================================

Mod:            JC's Leviathan: Ain't No Air in Space for K1
--------------------------------------------------------------------------------
Mod Author:     JCarter426
---------------
Game:           Star Wars: Knights of the Old Republic
--------------------------------------------------------------------------------
Attribution     "Leviathan: Ain't No Air in Space JCarter426" or "uses JC's
                Leviathan: Ain't No Air in Space" or some other reasonable
                phrasing.
--------------------------------------------------------------------------------

Attribution Only License (AOL)

* You've got mods! *

The creator of this mod has authorized the contents of this mod for public use.
Other modders are free to use and edit materials from this mod and include them
in other mods. This license applies to everyone equally and no further explicit
permission from the original mod creator is required, provided the terms of this
are followed.

- The user must provide clear attribution for the source and creator(s) of these
  materials, following the specified attribution preference. The file that
  contains this attribution must be included along with all the other mod
  contents.
  (For example, crediting the original mod creator in your mod's description on
  a website, but not in any file someone would actually download, would be a
  violation.)

- The user must include any additional credits as indicated.

- This license applies only for the use of these materials in other mods (i.e. a
  form of software accessed within a video game). This license does not grant
  the user unlimited power to distribute these contents, edited or unedited,
  even if attribution is granted. These materials are being offered to encourage
  the creation of new mods that alter the game experience. 
  (For example, distributing these materials as a mod resource on another
  website, or uploading the entirety of the mod as a "new" mod without really
  changing anything, would not be in the spirit of this license.)

- Where appropriate, it would be nice to provide a link to the original mod and/
  or tag the original mod creator. However, this is not mandated. This is just a
  polite suggestion.



================================================================================
6.  CREDITS
================================================================================

TSLPatcher          stoffe & Fair Strides
DeNCS               JdNoa & Dashus
ERFEdit             stoffe & Fair Strides
NWNSSCOMP           Torlack, stoffe, & tk102
xoreos tools        xoreos team
                    https://xoreos.org/



================================================================================
7.  DISCLAIMERS
================================================================================

THERE'S AN AIR AND SPACE MUSEUM.



================================================================================
8.  DONATIONS
================================================================================

If you enjoy my mods and would like to show your support in a monetary manner,
you may do so via PayPal with the donation link below.

http://www.paypal.me/carterunited

For various legal and ethical reasons, this is entirely optional and is not a
requirement to downloading or using any of my mods. I also do not create
specific mods for hire.

I make mods as a hobby and will most likely do so regardless of any donations or
lack thereof, but modding does take up a lot of my time and every bit helps.



================================================================================
9.  CONTACT
================================================================================

Questions? Problems? Suggestions? Something else?

Email me at kotor.hexATgmailDOTcom or PM me on Deadly Stream or wherever else
you can find me.