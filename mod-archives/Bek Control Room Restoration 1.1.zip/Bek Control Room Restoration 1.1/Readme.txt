Hidden Bek Control Room Restoration

A Mod for Star Wars Knights of The Old Republic

Author: N-DReW25
Release Date: 26.08.2016

Release Date 1.1: 10.10.2018



Installation: 
Simply Copy and Paste or Drag and Drop ALL the files within the "For Override" into your Star Wars Knights of The Old Republic override folder



Uninstallation: 
Remove or Delete the files from your Star Wars Knights of The Old Republic override folder



Description:
 In the Hidden Bek Base, their is a door labelled "Control Room" which cannot be unlocked, unlike the security doors that can be unlocked once you decide to finish a certain quest dark side. I found this annoying as the Control Room's interior is on the module loading screen, what this mod does is restore the Control Room and a small bit of Restored Content. This is less of 'cut content' and more of 'broken content' as I have reason to suspect this door was working on the Xbox version



Known Bugs: 
This mod shouldn't have bugs but if there is Just PM me on Deadlystream.



Incompatibilities:
 Would be incompatible with anything that edits "tar11_lockdoo001.utd"



Permissions: 
Do NOT claim credit for this mod



Thanks:
 Bioware for such an amazing game
Fred Tetra for Kotor Tool and everyone who downloads the mod.



Legal: 
THIS MODIFICATION IS NOT SUPPORTED BY BIOWARE/OBSIDIAN ENTERTAINMENT, LUCASARTS, DISNEY OR ANY LICENSERS/SPONSORS OF THE MENTIONED COMPANIES. USE OF THIS FILE IS AT YOUR OWN RISK AND THE ABOVE MENTIONED COMPANIES OR THE AUTHOR IS NOT RESPONSIBLE FOR ANY DAMAGE CAUSED TO YOUR COMPUTER FOR THE USAGE OF THIS FILE.