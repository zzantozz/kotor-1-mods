---------------------------
Knights of the Old Republic
---------------------------

TITLE: Effixian's Qel-Droma Robes Reskin for JC's Cloaked Jedi Robes
AUTHOR: Effix(ian)
CONTACT: PM me on the forums or find me on Steam

-----------
DESCRIPTION
-----------
This is an add-on reskin mod for JC's Cloaked Jedi Robes.
It gives the Qel-Droma Robes a unique texture based on Cay Qel-Droma.
This mod includes textures with and without gloves, which ones are used depends on which install option you picked when installing JC's mod.
I toned down Cay's comic book orange/golden tunic to a more sandy colour.
A matching HD icon is included.
This mod will not update a Qel-Droma Robes item that you've already acquired, you need a fresh one. You can either do that through cheats (giveitem g_a_jedirobe06) or by using a save from before you loot the item.

Requested by Salk.

Related mods:
Unique Qel-Droma Robes for JC's Cloaked Robes by StellarExile and Salk
https://deadlystream.com/topic/9152-modunique-qel-droma-robes-for-jcs-cloaked-robes/
Lore-Friendly Qel-Droma Robes HD by constantinople33
https://deadlystream.com/files/file/1851-lore-friendly-qel-droma-robes-hd/

------------
INSTALLATION
------------
Unzip. Copy the files from the subfolder to your game's Override folder.

----
BUGS
----
None known.

------------
UNINSTALLING
------------
Remove from the Override folder:
g_a_jedirobe06.uti
ia_JediRobe_055.tga
PFBI55.tga
PFBIA55.tga
PFBIB55.tga
PFBIC55.tga
PMBI55.tga
PMBIA55.tga
PMBIB55.tga
PMBIC55.tga

------------------
DISTRIBUTION NOTES
------------------
You can use the files from this mod in your own mod if you simply credit me.

---------
THANKS TO
---------
- JCarter426 for making the Cloaked Jedi Robes mod
- Salk for the request
- Fred Tetra for KotOR Tool

---------
Donations
---------
My mods are free. If you would like to show your support then you can buy me a coffee at ko-fi.com/effix

-------------------

THIS MODIFICATION IS NOT MADE, DISTRIBUTED, OR SUPPORTED BY BIOWARE, OBSIDIAN, OR LUCASARTS ENTERTAINMENT COMPANY LLC. ELEMENTS TM & � LUCASARTS ENTERTAINMENT COMPANY LLC AND/OR ITS LICENSORS.