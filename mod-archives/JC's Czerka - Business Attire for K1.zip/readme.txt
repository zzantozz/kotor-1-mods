================================================================================

    JC's Czerka:
    Business Attire                     v1.0

================================================================================

                                        by JCarter426

================================================================================
    TABLE OF CONTENTS
================================================================================

1.  Summary
2.  Installation
3.  Uninstallation
4.  Compatibility
5.  Permissions
6.  Credits
7.  Disclaimers
8.  Donations
9.  Contact



================================================================================
1.  SUMMARY
================================================================================

This mod gives Czerka Corporation uniforms to several Czerka employee characters
in the game who were missing them.



================================================================================
2.  INSTALLATION
================================================================================

1. Extract files from the downloaded archive.
2. Run Install.exe.
3. Click "Install Mod" and select your game directory (default name SWKotOR).



================================================================================
3.  UNINSTALLATION
================================================================================

1. Replace the following file with backup if necessary, otherwise remove:
   - modules/kas_m22aa.mod
   - modules/korr_m33aa.mod
   - modules/tat_m17ag.mod
   - modules/tat_m18aa.mod
   - override/appearance.2da
   - override/g_jordo.utc
   - override/JC_IthorianCz.mdl
   - override/JC_IthorianCz.mdx
   - override/JC_IthorianCz01.tpc
   - override/JC_RodianCz.mdl
   - override/JC_RodianCz.mdx
   - override/JC_RodianCz01.tpc



================================================================================
4.  COMPATIBILITY
================================================================================

This mod is compatible with the KOTOR 1 Community Patch.

This mod is compatible with the KotOR 1 Restoration mod.



================================================================================
5.  PERMISSIONS
================================================================================

This mod is released under the Creative Commons Attribution-NonCommercial 4.0
International license (CC BY-NC 4.0).

CC BY-NC: This license allows reusers to distribute, remix, adapt, and build
upon the material in any medium or format for noncommercial purposes only, and
only so long as attribution is given to the creator. 



================================================================================
6.  CREDITS
================================================================================

KOTOR Tool          Fred Tetra
TSLPatcher          stoffe & Fair Strides
ERFEdit             stoffe & Fair Strides
KOTORMax & MDLEdit  bead-v
NWMax               Joco
tga2tpc             ndix UR
xoreos tools        https://xoreos.org/
BSRGAN              https://github.com/cszn/BSRGAN

================================================================================
7.  DISCLAIMERS
================================================================================

CZERKA CORPORATION RECORDS ARE AVAILABLE AT OUR REPRESENTATIVE KIOSK ON
CORUSCANT. BUSINESS HOURS PLEASE.



================================================================================
8.  DONATIONS
================================================================================

If you enjoy my mods and would like to show your support in a monetary manner,
you may do so via PayPal with the donation link below.

http://www.paypal.me/carterunited

For various legal and ethical reasons, this is entirely optional and is not a
requirement to downloading or using any of my mods. I also do not create
specific mods for hire.

I make mods as a hobby and will most likely do so regardless of any donations or
lack thereof, but modding does take up a lot of my time and every bit helps.



================================================================================
9.  CONTACT
================================================================================

Questions? Problems? Suggestions? Something else?

Email me at kotor.hexATgmailDOTcom or PM me on Deadly Stream or wherever else
you can find me.