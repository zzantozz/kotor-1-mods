================================================================================

	JC's Vision Enhancement for K1
						v1.1

================================================================================

						by JCarter426

================================================================================
    TABLE OF CONTENTS
================================================================================

1.  Summary
2.  Installation
3.  Uninstallation
4.  Compatibility
5.  Permissions
6.  Credits
7.  Disclaimers
8.  Donations
9.  Contact



================================================================================
1.  SUMMARY
================================================================================

Throughout the game, there are cutscenes of the player sleeping and having Force
visions to further the plot. This mod fixes two things about those scenes that
bothered me.

First, the first of these scenes is supposed to happen in the party's apartment
on Taris, but is quite clearly set on the Ebon Hawk like all the other scenes.
I've edited the area used for the visions to put in a copy of the apartment to
make the location consistent.

Second, the scenes show the player wearing whatever item they happened to have
equipped when the scene started. So the player would routinely sleep in their
clothing, even armor. I've edited the cutscene scripts to remove the player's
equipment for the duration of the vision.



================================================================================
2.  INSTALLATION
================================================================================

1. Extract files from the downloaded archive.
2. Run Vision_Enhancement_K1.exe.
3. Select which version to install:
   If you use the KOTOR 1 Restoration choose the K1R-Compatible Installation.
   Otherwise, choose the Basic Installation.
4. Click "Install Mod" and select your game directory (default name SWKOTOR).



================================================================================
3.  UNINSTALLATION
================================================================================

1. Remove the installed file.



================================================================================
4.  COMPATIBILITY
================================================================================

This mod is not compatible with any other mods that alter the vision module
STUNT_00.



================================================================================
5.  PERMISSIONS
================================================================================

I hereby grant nobody except myself permission to upload some or all of this mod
anywhere for any reason. For any reason.

If you would like to include any part of this mod in anything, then please
contact me for permission.



================================================================================
6.  CREDITS
================================================================================

KOTOR Tool		Fred Tetra
TSLPatcher		stoffe
			with updates by Fair Strides
DeNCS			JdNoa & Dashus
ERFEdit			stoffe
			with updates by Fair Strides
K-GFF			tk102
KOTORMax & MDLEdit	bead-v
NWMax			Joco
NWNSSCOMP		Torlack, stoffe, & tk102

and thanks to DarthParametric for decompiling a script for me. It's an ongoing
mystery why DeNCS refuses to decompile certain scripts for me and only me.



================================================================================
7.  DISCLAIMERS
================================================================================

"I AM NOT A VISION" SAYS THE VISION. HA! WELL, THEN, I AM NOT KOTOR, DEVELOPED
BY BIOWARE, NO. I AM NOT A VIDEO GAME EITHER.



================================================================================
8.  DONATIONS
================================================================================

If you enjoy my mods and would like to show your support in a monetary manner,
you may do so via PayPal with the donation link below.

http://www.paypal.me/carterunited

For various legal and ethical reasons, this is entirely optional and is not a
requirement to downloading or using any of my mods. I also do not create
specific mods for hire.

I make mods as a hobby and will most likely do so regardless of any donations or
lack thereof, but modding does take up a lot of my time and every bit helps.



================================================================================
9.  CONTACT
================================================================================

Questions? Problems? Suggestions? Something else?

Email me at kotor.hexATgmailDOTcom or PM me on Deadly Stream or wherever else
you can find me.