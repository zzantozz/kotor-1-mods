Robes With Shadows For K1 (JC's Cloaked Jedi/Hybrid Robes) v1.2.0

[Description:]
I have created a simple mod that adds the shadows for robes used in Robes With Shadows For TSL to your K1 game, for those using any of JC's robe mods 
thats adds TSL-style cloaks. Having one of the mods listed below is a requirement for this one, and they must be installed beforehand. This is 
compatible with all included versions of the mods by JC, and any textures you are using with it.

"JC's Fashion Line I: Cloaked Jedi Robes for K1": for those who want to use the more classic looking Jedi robes of TSL in their K1 game.
(https://deadlystream.com/files/file/1378-jcs-fashion-line-i-cloaked-jedi-robes-for-k1/) 
"JC's Fashion Line I: Cloaked Hybrid Robes for K1": for a blend of the K1 and TSL style.
(https://deadlystream.com/files/file/1758-jcs-fashion-line-i-cloaked-hybrid-robes-for-k1/)
"JC's Fashion Line I: Cloaked Party Robes": for party member specific robes.
(https://deadlystream.com/files/file/1756-jcs-fashion-line-i-cloaked-party-robes-for-k1/)

[Installation:]
First, install at least one of the mods listed above if you have not already. This mod is specifically for people using one of those mods. If you would 
like to create backups of that mod's original files, just create a copy of the files listed below, before installing the versions that come with this 
mod. 
When installing this mod, find the subfolder with the name corresponding to which JC mod you are using, and copy all files within to the override 
folder of your game, found in the same directory as your main game executable. For Steam installations, this would be 
"Steam\steamapps\common\swkotor\override". When prompted, overwrite the versions of the files currently in your override with the new versions.

[Uninstallation:]
Remove the files in the Included Files list below from your override. Which files you have can vary by which JC mod you are using.

[Included Files:]
-PFBIL.mdl
-PFBIL.mdx
-PFBIM.mdl
-PFBIM.mdx
-PFBIS.mdl
-PFBIS.mdx
-PMBIL.mdl
-PMBIL.mdx
-PMBIM.mdl
-PMBIM.mdx
-PMBIS.mdl
-PMBIS.mdx
-JC_BastilaBI.mdl
-JC_BastilaBI.mdx
-JC_JoleeBI.mdl
-JC_JoleeBI.mdx
-JC_JuhaniBI.mdl
-JC_JuhaniBI.mdx

[Compatibility:]
Users should expect full compatibility with any other mods, so long as they do not modify/replace the above files. Texture mods do not typically 
pose compatibility issues for mods like this. This mod requires either "JC's Fashion Line I - Cloaked Jedi Robes for K1", "JC's Fashion Line I - 
Cloaked Hybrid Robes for K1", or "JC's Fashion Line I - Cloaked Party Robes for K1" to be installed first.

[Acknowledgments:]
Big thanks to JCarter for his port of TSL robes to K1, and for giving the community permission to work with his models. The robes included here are 
just the ones from his mod with edited skeletons, so most of the work here was done for me. I also want to thank Symmetric, Purifier, Ndix UR, 
and seedhartha for making importing to Blender simple using KotORBlender, modeling work would be much tougher without you guys. I would like to thank 
Salk as well, for suggesting this mod.

This modification is not supported by Bioware, Lucasarts, Disney or any licensers/sponsors thereof. Use of this modification is at your own risk and 
neither the aforementioned companies nor the author may be held responsible for any damages caused to your computer via this modification's usage.
 