================================================================================

	JC's Mandalorian Armor for K1		v1.2

================================================================================

						by JCarter426

================================================================================
    TABLE OF CONTENTS
================================================================================

1.  Summary
2.  Installation
3.  Uninstallation
4.  Compatibility
5.  Permissions
6.  Credits
7.  Disclaimers
8.  Contact



================================================================================
1.  SUMMARY
================================================================================

This mod adjusts the wearable Mandalorian armor items to make their appearances
consistent with that of other Mandalorians in the game and to fix various other
oddities associated with them.

The main part of the mod concerns the Class 9 Mandalorian armors (Mandalorian
Battle Armor, Mandalorian Heavy Armor, and Mandalorian Assault Armor). These
items will now follow the usual blue/red/gold ranking system. There are two
options for this:

- With Option A, the armors use the Class 9 model. Mandalorian Heavy Armor and
  Mandalorian Assault Armor are given new textures, recolored red and gold
  variants of the Mandalorian Battle Armor.

- With Option B, the armors act as disguise items, giving the wearer one of the
  NPC Mandalorian appearances.

Both options also include the following:

- Class 9 Mandalorian armors have new icons to match their appearance with each
  option

- Class 8 Mandalorian Armor has a new icon with the correct appearance
  (previously it looked purple)

- The Mandalorian helmet plot items have new icons to match their appearances
  (previously they were both blue, even though neither was dropped by a blue
  Mandalorian)

- The Mandalorian Commander on Kashyyyk drops Mandalorian Heavy Armor to match
  his red appearance (also, I believe this item couldn�t be found anywhere in
  the game before)

Finally, there is a third Extra Textures option with texture overrides for the
NPC Mandalorians (and disguise appearances). They tone down the shaders a bit,
matching what I did with my Shader Fixes for K2. They can be installed alongside
Option A or B.



================================================================================
2.  INSTALLATION
================================================================================

1. Run Mandalorian_Armor_K1.exe.
2. Select which version to install.
   a) With Option A, Class 9 Mandalorian armors are recolored to match their
      usual ranking system (blue/red/gold).
   b) With this option, Class 9 Mandalorian armors act as disguise items, giving
      the wearer one of the NPC Mandalorian appearances (blue/red/gold) with
      full body armor.
3. Click "Install Mod" and select your game directory (default name SWKOTOR).
4. The Extra Textures can be installed alongside either Option A or B. If you
   want to install these, run the EXE again, select the Extra Textures option,
   then install to your game directory as before.



================================================================================
3.  UNINSTALLATION
================================================================================

1. Remove the installed files or replace from backups if necessary.



================================================================================
4.  COMPATIBILITY
================================================================================

This mod replaces the unused PFBH07/PMBH07 texture variations and uses plot
usable item variation 111.

Some users have experienced side effects after prolonged exposure to disguise
items. It may result in a character's appearance being permanently changed.
There is no confirmed prevention method at this time, but it can be treated via
editing the save game file.

If Option A is installed, it will overwrite any other alterations to the
Mandalorian Assault Armor. Currently, TSLPatcher cannot remove nodes from files,
so a hard edit was necessary to remove the disguise property.



================================================================================
5.  PERMISSIONS
================================================================================

I hereby grant nobody except myself permission to upload some or all of this mod
anywhere for any reason. For any reason.

If you would like to include any part of this mod in anything, then please
contact me for permission.



================================================================================
6.  CREDITS
================================================================================

KOTOR Tool		Fred Tetra
TSLPatcher		stoffe
K-GFF			tk102
KOTORMax		bead-v
NWMax			Joco
tga2tpc			ndix UR



================================================================================
7.  DISCLAIMERS
================================================================================

FOR MANDALORE!!!!!!!



================================================================================
8.  DONATIONS
================================================================================

If you enjoy my mods and would like to show your support in a monetary manner,
you may do so via PayPal with the donation link below.

http://www.paypal.me/carterunited

For various legal and ethical reasons, this is entirely optional and is not a
requirement to downloading or using any of my mods. I also do not create
specific mods for hire.

I make mods as a hobby and will most likely do so regardless of any donations or
lack thereof, but modding does take up a lot of my time and every bit helps.



================================================================================
9.  CONTACT
================================================================================

Questions? Problems? Suggestions? Something else?

Email me at kotor.hexATgmailDOTcom or PM me on Deadly Stream or wherever else
you can find me.