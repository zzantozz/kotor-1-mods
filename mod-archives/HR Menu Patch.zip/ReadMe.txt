========================================================
	K1 Galaxy Map Fix Pack / Canon Galaxy Map for K1
	Patch for ndix UR's "KotOR High Resolution Menu"
	for Knights of the Old Republic
	by Sith Holocron and Kexikus
========================================================


This is a patch to make "K1 Galaxy Map Fix Pack" by Sith Holocron and Kexikus or "Canon Galaxy Map for K1" by Kexikus compatible with "KotOR High Resolution Menu" by ndix UR.

IMPORTANT: This only works without the Ord Mantell planet mod installed and the apropriate version of the mods listed above.

# Installation:

FIRST: Install "KotOR High Resolution Menu" and either "K1 Galaxy Map Fix Pack" or "Canon Galaxy Map for K1".
SECOND: Find the folder for your resolution from this archive and copy its content into your Override folder, overwriting the existing galaxymap.gui.

# Permissions:
All materials and copyrights belong to LucasArts, Bioware and Obsidian 
Entertainment Inc., we own none of the materials, and we are not making 
any money out of this mod. It is to be distributed as-is without alteration, 
unless by permission of the mod authors. This mod is not to be distributed 
for profit, either.

We hereby state that we specifically do NOT wish this mod to be uploaded to 
Steam Workshop.

# Credits:
Snigaroo: Suggesting to make this compability patch
ndix UR: Actually making the patch
A Future Pilot: Help in bringing everything together

# Thanks:
Fred Tetra: Kotor Tool
Stoffe: TSLPatcher
tk102: K-GFF GFF Editor

# Contact:
Send us a personal message on www.deadlystream.com. 

THIS MODIFICATION IS PROVIDED AS-IS AND IS NOT SUPPORTED BY 
BIOWARE/OBSIDIAN ENTERTAINMENT OR LUCASARTS OR ANY LICENSERS/SPONSORS OF THE MENTIONED COMPANIES. USE OF THIS 
FILE IS AT YOUR OWN RISK AND THE ABOVE MENTIONED COMPANIES OR 
THE AUTHORS ARE NOT RESPONSIBLE FOR ANY DAMAGE CAUSED TO 
YOUR COMPUTER FOR THE USAGE OF THESE FILES.