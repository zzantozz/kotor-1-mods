A KNIGHTS OF THE OLD REPUBLIC MODIFICATION

 
High Quality Blasters
By Sithspecter

Description:

When Knights of the Old Republic won Game of the Year in 2004, none of the awards were for the blaster models. While the storyline and gameplay are top notch, the default weapons are sadly lacking in quality. Extremely low polygon models combined with 64 px by 64 px textures make them horrendous to look at. On my last playthrough of KotOR, I had enough of the ugly blasters. Who wants to pay thousands of credits for a terrible looking grey-ish blob that's supposed to be a top notch firearm? Nobody, that's who! So I sought out to fix this problem and provide high quality models and textures.

This mod completely replaces the existing blasters with newly modeled firearms, complete with high quality textures. Special care was taken to retain the form and look of the original items, but in a high quality package. Each weapon was carefully textured based on close examination of its default counterpart. It's a much improved package that I hope will be a permanent addition to your KotOR override folder for years to come.

Use:

Use of High Quality Blasters is extremely easy. Run the installer, and then play. That's it!

The new models will automatically appear when you load up your last save.
 
However, this mod does make a couple .uti changes to avoid doubling up on weapon textures. I've applied a new model and texture to a few items that share a model and texture in the default game. The following items are affected:

Baragwin Assault Gun
Baragwin Disruptor-X Weapon
Baragwin Heavy Repeating Blaster
Baragwin Ion-X Weapon
Carth's Blaster
Genoharadan Blaster

What this means is that if you already have one of these items, it will still show up as high quality, but it will share a texture with another high quality item. If you re-acquire one of these through cheats or KSE, it will appear properly. If you start a new game, everything will appear properly. This will not negatively affect the gameplay in anyway.

A note about the Sith Sniper Rifle:
 
I discovered that the Sith Sniper Rifle is widely used as a blaster wielded by Sith Troopers. It looks somewhat comical used by them (predominantly fired from the hip). So, I have included something of a patch that allows the Sith Troopers to use a regular looking version of it with the new texture. The Sniper version can be found at Kebla Yurt's store in the Upper City North of Taris and in a container in the Sith Academy on Korriban. If you want to cheat more Sith Sniper Rifles that look like a sniper, use the following code:
 
giveitem g_w_blstrrfl006
 
Installation:

1. Run "High Quality Blasters Installer.exe" in the zip file.
2. Follow the on screen instructions, and point the Installer to your game folder (not Override folder)
3. Profit

Version 1.1: If you have installed High Quality Blasters previously, you can install this version over it and it will still be fine. However, if you want to fix the bug of the blaster randomly appearing under the Ebon Hawk on Tatooine, you must remove the following files (make sure of exact filenames):
�	w_ionrfl_004.mdl (NOT w_ionrfl_04.mdl)
�	w_ionrfl_004.mdx (NOT w_ionrfl_04.mdx)

INCOMPATIBILITY:

IF YOU HAVE TOASTY FRESH'S TOTAL WEAPON OVERHAUL OR FALLEN GUARDIAN'S WEAPON MODEL OVERHAUL TEXTURE REWORK, YOU SHOULD BE ABlE TO INSTALL THIS MOD OVER THOSE MODS WITHOUT AN ISSUE. 

HOWEVER: DO NOT INSTALL TOASTY FRESH'S TOTAL WEAPON OVERHAUL OR FALLEN GUARDIAN'S WEAPON MODEL OVERHAUL TEXTURE REWORK OVER THIS MOD. IT WILL LIKELY CAUSE THE TEXTURES TO BE WRONG.

Bugs:

Due to differences between the body models (especially female), the weapons will sometimes appear to clip the hands especially in the female off-hand). There is nothing I can do about this without introducing more issues, it is something that happens with the default weapons, and you will have to live with it.

Changelog:

Version 1.1:

Fixed an issue where a blaster rifle randomly appeared under the Ebon Hawk on Tatooine.
Fixed an issue where Bith instruments were replaced by pistols.
Fixed the Assassin Droid and War Droid models to accept the high quality repeating blaster texture for their weapons.

Credit:

Thanks to 90SK, Fair Strides, Varsity Puppet, and Kexikus for providing feedback for this mod.
Credit goes to Kexikus for the inspiration from your screenshots. They look fantastic so I modeled the screenshots for this mod
after your High Definition Skyboxes mod.

Permissions:

Do not upload this mod or assets from this mod, modified or not, to other sites without my express permission. I have uploaded this mod to multiple sites and can provide support on those sites.
 
Legal:
THIS MODIFICATION IS PROVIDED AS-IS AND IS NOT SUPPORTED BY BIOWARE/OBSIDIAN ENTERTAINMENT, LUCASARTS, DISNEY OR ANY LICENSERS/SPONSORS OF THE MENTIONED COMPANIES. USE OF THIS FILE IS AT YOUR OWN RISK AND THE ABOVE MENTIONED COMPANIES OR THE AUTHOR IS NOT RESPONSIBLE FOR ANY DAMAGE CAUSED TO YOUR COMPUTER FOR THE USAGE OF THIS FILE.