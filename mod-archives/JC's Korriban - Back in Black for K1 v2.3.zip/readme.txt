================================================================================

	JC's Korriban: Back in Black for K1	v2.3

================================================================================

						by JCarter426

================================================================================
    TABLE OF CONTENTS
================================================================================

1.  Summary
2.  Installation
3.  Uninstallation
4.  Compatibility
5.  Permissions
6.  Credits
7.  Disclaimers
8.  Donations
9.  Contact



================================================================================
1.  SUMMARY
================================================================================

Almost everybody on Korriban wears the standard bland Sith officer uniform.
This mod alters the look of almost everybody on the planet so they're dressed
more appropriately. Czerka workers wear Czerka uniforms, Sith troopers wear
Sith armor, Dark Jedi wear Dark Jedi robes.

While I was going through all the files I noticed some other oddities and
corrected them - things like missing items or misplaced files. See the change
log for a full list of changes.



================================================================================
2.  INSTALLATION
================================================================================

Note: It is recommended that you uninstall any previous versions of this mod
      before installing a new version.

1. Extract files from the downloaded archive.
2. Run Korriban_Back_in_Black_K1.exe.
3. Select which version to install.
   If you have the KOTOR Community Patch installed, choose the KOTOR Community
   Patch-Compatible Installation option. Otherwise, choose the Basic
   Installation option.
4. Click "Install Mod" and select your game directory (default name SWKOTOR).
5. There are additional options for Uthar, Yuthura, and Tariga that you may
   install after the rest of the mod is installed.



================================================================================
3.  UNINSTALLATION
================================================================================

1. Remove the installed files or replace from backups if necessary.



================================================================================
4.  COMPATIBILITY
================================================================================

This mod may be compatible with but will overwrite other mods that alter the
appearance or equipment of characters on Korriban. It's safest not to use it
with any other mod that alters the same characters.

Some of the changes will take effect immediately, but for best results you
should install this mod before visiting Korriban for the first time in your
game.



================================================================================
5.  PERMISSIONS
================================================================================

I hereby grant nobody except myself permission to upload some or all of this mod
anywhere for any reason. For any reason.

If you would like to include any part of this mod in anything, then please
contact me for permission.



================================================================================
6.  CREDITS
================================================================================

KOTOR Tool		Fred Tetra
TSLPatcher		stoffe
			with updates by Fair Strides
DeNCS			JdNoa & Dashus
ERFEdit			stoffe
			with updates by Fair Strides
K-GFF			tk102
NWNSSCOMP		Torlack, stoffe, & tk102



================================================================================
7.  DISCLAIMERS
================================================================================

OBSIDIAN IS THE NEW BLACK. DON'T WEAR BIOWARE AFTER LABOR DAY.



================================================================================
8.  DONATIONS
================================================================================

If you enjoy my mods and would like to show your support in a monetary manner,
you may do so via PayPal with the donation link below.

http://www.paypal.me/carterunited

For various legal and ethical reasons, this is entirely optional and is not a
requirement to downloading or using any of my mods. I also do not create
specific mods for hire.

I make mods as a hobby and will most likely do so regardless of any donations or
lack thereof, but modding does take up a lot of my time and every bit helps.



================================================================================
9.  CONTACT
================================================================================

Questions? Problems? Suggestions? Something else?

Email me at kotor.hexATgmailDOTcom or PM me on Deadly Stream or wherever else
you can find me.