
This fix was originnaly made by Redrob41 and was located by me in one of his large mods. I was given persmission by the admins to release it to the public.

All credits goes to Redrob41, Please contact me if you would like this mod removed.

This elongates the handle on the blade so your hands no longer grab the blade directly like it used to.

To install just place the contents in the zip to you override!

To uninstall just remove.

Thanks for the download!

-Sdub