
Title: Calo Nord Reskin

-------------------------------------------------------------------------------------------

Released: 05/26/08

-------------------------------------------------------------------------------------------

Author: Watcher07

-------------------------------------------------------------------------------------------

All this is is a simple recoloring of Calo Nords appearance.  It mutes the colors on his clothes and darkens them.  Screenshots are included for ya.  Hope you like it.

-------------------------------------------------------------------------------------------

To Install:

Copy the file N_CaloNord01 from the Override folder OF THIS FOLDER to the Override folder of your game.  If you don't have an override folder, just create one called Override in the main game directory and put this file into it.  Then get to playing and enjoy the revamped Calo Nord.

-------------------------------------------------------------------------------------------

Permissions:

All I did was extract the .tga and recolor it in photoshop.  I don't mind if it gets used in anyone elses mods as long as you give me a little credit.  Actually it would be pretty cool if it did, but I'm just happy to have it out there.

-------------------------------------------------------------------------------------------

Notes:

The screenshots show two additional mods that are NOT included with this.  The Republic Uniform Reskin is from DarkDiva and can be found on the kotor files website.  The guns Calo is holding in the screenshot are from the Weapons of the Old Republic mod by T7Nowhere which can also be found on the kotor files website.  Thank you.

-Watcher07