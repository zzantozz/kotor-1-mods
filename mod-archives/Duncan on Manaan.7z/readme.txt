Author : Seamhainn

This mod restores the appearance of Duncan Deatheye, Taris's hapless duelist, on Manaan. He tells you his story and then walks away.

You must be the Taris Arena Champion for Duncan to appear.

Installation
------------
Copy the files to your SWKotor\Override folder.
Or use Kotor Mod Manager for installation.

Note: For this mod to work you must either start a new game or use a save that you haven't been to Manaan yet.

I can be contacted via PM: Seamhainn on www.lucasforums.com

Have fun!