================================================================================

	JC's Minor Fixes for K1		v1.1

================================================================================

					by JCarter426

================================================================================
    TABLE OF CONTENTS
================================================================================

1.  Summary
2.  Installation
3.  Uninstallation
4.  Contents
5.  Straight Fixes
6.  Bug Fixes
7.  Resolution Fixes
8.  Aesthetic Improvements
9.  Things What Bother Me Fixes
10. Permissions
11. Credits
12. Disclaimers
13. Contact



================================================================================
1.  SUMMARY
================================================================================

This is a collection of various things that I found annoying enough to alter.
I collect things that I don't think warrant their own mods into a single mod,
to be released to the general public when it becomes more substantial.



================================================================================
2.  INSTALLATION
================================================================================

Due to the nature of this mod, I haven't bothered to make a proper installer
with TSLPatcher. Just install whatever you want to install. Don't install
whatever you don't want to install.

It is recommended that you remove any previous versions of this mod before
installation.

All files go in the Override folder.

Contact me for any questions about mod compatibility.



================================================================================
3.  UNINSTALLATION
================================================================================

Remove any files you installed from your Override folder.



================================================================================
4.  CONTENTS
================================================================================

I've divided this mod into five categories: Straight Fixes, Bug Fixes,
Resolution Fixes, Aesthetic Improvements, and Things What Bother Me Fixes.

Straight Fixes are fixes for issues I think are genuine errors or mistakes or
oversights or what have you. There's a problem, here's a fix for it. No artistic
license is involved.

Bug Fixes really fall under straight fixes but I've separated them into their
own category because they're more severe and there's absolutely no reason not to
have them. They fix bugs that could potentially break your game. What I've
included are either well known and easy for me to do a quick fix or came to my
attention directly. There are lots of other bugs this mod doesn't fix, so I
strongly suggest that you seek out a more extensive bug-fixing mod.

Resolution Fixes are all textures from the game for which there were identical,
higher resolution textures somewhere else in the game files. So I've swapped the
lower resolution ones for the higher resolution ones. I've separated these from
the straight fixes because a) I didn't make any of the content here - it's all
extracted from the game, and b) they don't actually fix "problems" per se - it's
just an increase in resolution. It looks the same, with slightly more pixels.

Aesthetic Improvements are my attempts to improve the visual quality in certain
areas. I've tried to maintain the original aesthetic of the game while improving
the quality. But the nature of the improvements necessitates new content created
by me. You might not like my work, or you might use a different mod that touches
on these areas, or whatever, so I've isolated these from the other fixes.

Things What Bother Me Fixes fix things what bother me. They might not bother you
but they bother me, so I've isolated those as well.

For a full release history, see the accompanied file.


================================================================================
5.  STRAIGHT FIXES
================================================================================

PLOT CRYSTAL ICONS

The three different crystals you can use to construct your first lightsaber all
had the wrong icon.

- dan13_bluecryst.uti
- dan13_goldcryst.uti
- dan13_grncryst.uti


SITH FIGHTER LASERS

They were the wrong color.

- LMG_blaster02.tpc


STUNT MODULE FIXES

These add in area geometry that was missing from some of the stunt modules used
for cutscenes. They removed all the rooms that wouldn't be visible for the
cutscene, but some of them... would be visible.

- stunt_endbridge.lyt
- stunt_endbridge.vis
- stunt_starforge.lyt
- stunt_starforge.vis


TXI FIXES

Added missing shaders for these textures.

- LKA_leaf01.tpc
- LKA_leaf02.tpc
- lka_leaf03.tpc
- P_BastilaBB01.tpc
- PLC_Hyper.tpc



================================================================================
6.  BUG FIXES
================================================================================

XOR / MESSENGER QUEST FIX

After the Xor encounter, other messenger quests would be bugged.

- k_hxor_state03.ncs



================================================================================
7.  RESOLUTION FIXES
================================================================================

All of these are textures from the game, replaced with the highest resolution
versions of those textures I could find in the game files.



================================================================================
8.  AESTHETIC IMPROVEMENTS
================================================================================

COMMONER CLOTHING

Fixed some issues with the male commoner clothing variants.

- N_ComM02.tga
- N_ComM03.tga
- N_ComM04.tga
- N_ComM05.tga
- N_ComM06.tga
- N_ComM08.tga


CZERKA PROTOCOL OFFICER

The lady that run things on Tatooine has had her head edited to make her hair
less horrible looking.

- n_tatcoma_f.tga


SITH SOLDIER CORPSE

The placeable Sith corpse had a low resolution texture (256x256) with part of it
identical to the higher resolution Sith soldier texture (512x512). I've edited
it to combine the two and improve the quality.

- PLC_SSldCrps.tpc



================================================================================
9.  THINGS WHAT BOTHER ME FIXES
================================================================================

KIOSK 2 MODEL

Fixed some oddities on the PLC_Kiosk2 model. There were some random metal things
just hovering in the air, some bad UVW mapping, and I always thought the droid
head looked a bit anachronistic. I mean, more like the droids of the film era 
than the ones in the game. It's also a lot smaller than the ones in the game,
so I decided to remove it rather than replace it.

- plc_kiosk2.mdl
- plc_kiosk2.mdx


SECURITY CAMERA ANNOYANCE FIX

LEAVING AHTO CITY SECURITY ZONE. CAMERAS DEACTIVATED.
ENTERING AHTO CITY SECURITY ZONE. CAMERAS ACTIVATEd.
LEAVING AHTO CITY SECURIT--

I made those annoying things into bark bubbles instead of cutscenes so you can
ignore them and continue on your way.


SITH UNIFORM ANIMATION REMOVAL

This removes the custom animations that are present on the Sith uniform models.
Yeah, removes. It might sound weird to call that a fix, but I thought they
looked bad. The Sith just have a looping idle animation and then the rest is all
from the stock set, but there's no transition between the two. It jerks from one
animation to another. Additionally, the placement of Saul's hands was... an
interesting choice. So my solution was just to remove them all and make them use
all the regular people animations.

- N_AdmrlSaulKar.mdl
- N_AdmrlSaulKar.mdx
- N_SithComF.mdl
- N_SithComF.mdx
- N_SithComM.mdl
- N_SithComM.mdx



================================================================================
10. DISTRIBUTING AND INCLUDING THIS MOD
================================================================================

If you want to include any of the Straight Fixes, Resolution Fixes, or Bug Fixes
in your mod, you're free to do so. All I ask is for proper credit.

For the rest of the fixes (i.e. Aesthetic Improvements and Things What Bother Me
Fixes), please contact me. I'll consider requests on a case by case basis.

As for the mod in its entirety, I hereby grant nobody except myself permission
to upload it anywhere for any reason. For any reason.



================================================================================
11. CREDITS
================================================================================

KOTOR Tool		Fred Tetra
NWMax			Joco
KOTORMax & MDLEdit	bead-v
DLGEditor		tk102
NWNSSCOMP		Torlack, stoffe, & tk102
tga2tpc			ndix UR



================================================================================
12. DISCLAIMERS
================================================================================

This game modification is not supported by LucasArts, if it still exists, or
BioWare; I'm just cleaning up after their mess. Er, I mean, applying what
little talent I have to augment their already superb work.

This game modification is provided as is. I do not take responsibility for
any damage this causes to your game, your computer, or your personal mental
wellbeing.

YOU CHILDREN KNOW TOO MUCH. YOU MUST STAY IN THE DISNEY VAULT... FOREVER.



================================================================================
13. CONTACT
================================================================================

Questions? Problems? Suggestions? Something else?

Email me at kotor.hexATgmailDOTcom or PM me on Deadly Stream or wherever else
you can find me.