[K1/TSL] Hi-Res Beam Effects 2.0
================================
by Darth InSidious
==================

v2.0, 04/10/2014
----------------
-Combined Force Lightning and Death Field and Hi-Res Beam Effects mods into one package;
-Replaced TSL version hi-res beam effects with K1 versions.

Description
-----------

This mod replaces the Force Drain, Force Lightning, Death Field, cold ray, ion, and neural pacifier beam effects with higher resolution versions.


Installation
------------
Just drop the files Fx_Drain, Fx_Lightning, fx_beam01, fx_beam02, and fx_beam03 in this archive into your Override folder.

Uninstallation
--------------
Take the files out again. :)

Legal Disclaimer
----------------
All materials and copyrights belong to LucasArts, Bioware and Obsidian Entertainment Inc., 
Kotor Tool belongs to Fred Tetra, NWNSSCOMP belongs to Edward T. Smith.
I own none of the materials, and I'm not making any money out of this mod. It is to be distributed 
as-is without alteration, unless by permission of the mod author. This mod is not to be distributed for profit, either.
Use it how you like, but if you're going to post it up somewhere, or make a derivate mod, or use it in another mod, you must 
ask me first.

Thanks to:
----------
Quanon and Zhaboka for the feedback on the original TSL hi-res beam effects;
Fred Tetra for the truly awesome KotOR tool and his nwnsscomp conversion;
Holowan in general for being helpful, friendly and all the rest of the good stuff it is :) ;
KotORFiles, for being simply the best website in the history of the internet...Propaganda? What's that? ;
Lucasarts and Bioware for KotOR, and Obsidian, too, for TSL, without which, I couldn't have made this ;) .