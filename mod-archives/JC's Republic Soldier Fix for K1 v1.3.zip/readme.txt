================================================================================

		JC's Republic Soldier Fix for K1		v1.3

================================================================================

								by JCarter426

================================================================================
    TABLE OF CONTENTS
================================================================================

1.  Summary
2.  Installation
3.  Uninstallation
4.  Compatibility
5.  Credits
6.  Distributing and Including This Mod
7.  Disclaimers
8.  Contact



================================================================================
1.  SUMMARY
================================================================================

I became so very tired of the low resolution textures for female Republic
soldiers. So I made a new model for them, using the male version as a template.

While I was at it, I noticed errors on the male model, so I've corrected those
as well.



================================================================================
2.  INSTALLATION
================================================================================

1. Copy the files from Override to your own Override folder (if you don't have
   one, make one).

2. Optionally, copy the files from the Optional folder to your Override folder.
   This will replace the clothing for soldier-class players with my fixed
   Republic soldier armor.



================================================================================
3.  UNINSTALLATION
================================================================================

1. Remove the installed files.



================================================================================
4.  COMPATIBILITY
================================================================================

This mod is not compatible with any mods that alter the Republic soldier body
models.

There may also be problems with other mods that utilize the model N_RepSold_F,
since the texture mapping has been changed. The new female model uses the same
texture mapping as the original male model, so compatibility is still possible
either by using the male textures instead, or editing appearance.2da.



================================================================================
5.  CREDITS
================================================================================

KOTOR Tool		Fred Tetra
NWMax			Joco
KOTORMax & MDLEdit	bead-v

Hands fixed by DarthParametric. Thanks!



================================================================================
6.  DISTRIBUTING AND INCLUDING THIS MOD
================================================================================

I hereby grant nobody except myself permission to upload some or all of this mod
anywhere for any reason. For any reason.

If you would like to include any part of this mod in anything, then please
contact me for permission.



================================================================================
7.  DISCLAIMERS
================================================================================

THE CONGRESS OF BIOWARE CONCURS WITH THE HONORABLE DELEGATE FROM OBSIDIAN
ENTERTAINMENT. A COMMISSION MUST BE APPOINTED.



================================================================================
8. CONTACT
================================================================================

Questions? Problems? Suggestions? Something else?

Email me at kotor.hexATgmailDOTcom or PM me on Deadly Stream or wherever else 
you can find me.