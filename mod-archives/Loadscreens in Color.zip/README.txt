A KNIGHTS OF THE OLD REPUBLIC MODIFICATION
 
Loadscreens in Color
By Sithspecter

Description:

Knights of the Old Republic is a fantastic game. There isn't a whole lot that can be improved on. However, one area of the game that could, quite literally, use some more color is the loading screens.

This mod replaces all the default black and white loading screens with loading screens that are in color. Each of the loading screens has been reproduced shot for shot, with a few exceptions where the angle was not possible or didn't showcase the area very well. Extra care was taken to produce a look very similar to the original, but in color. The result, in my opinion, really freshens the game and invokes the feel of the area being traveled to.
 
Installation:

Installation of Loadscreens in Color is extremely easy. Drop all the files in the "Override" folder in this archive into your Knights of the Old Republic Override folder.

The new loading screens will automatically appear, you will not have to start a new game!

INCOMPATIBILITY:

IF YOU HAVE ANOTHER MOD THAT ALTERS THE LOADING SCREENS, YOU WILL HAVE TO CHOOSE ONE OR THE OTHER. INSTALLING THESE FILES WILL OVERWRITE OTHER LOADING SCREEN MODS.

Bugs:

None known.

Credits:

Credit goes to Kexikus for High Quality Skyboxes, which were installed when I took the screenshots.

Credit goes to Darth InSidious for his Sonic Screwdriver, which was handy to open doors that wouldn't have been easily opened otherwise.

Permissions:

Do not upload this mod or assets from this mod, modified or not, to other sites without my express permission. I have uploaded this mod to multiple sites and can provide support on those sites.
 
Legal:
THIS MODIFICATION IS PROVIDED AS-IS AND IS NOT SUPPORTED BY BIOWARE/OBSIDIAN ENTERTAINMENT, LUCASARTS, DISNEY OR ANY LICENSERS/SPONSORS OF THE MENTIONED COMPANIES. USE OF THIS FILE IS AT YOUR OWN RISK AND THE ABOVE MENTIONED COMPANIES OR THE AUTHOR IS NOT RESPONSIBLE FOR ANY DAMAGE CAUSED TO YOUR COMPUTER FOR THE USAGE OF THIS FILE.