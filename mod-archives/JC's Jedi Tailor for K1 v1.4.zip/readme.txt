================================================================================

	JC's Jedi Tailor for K1				v1.4

================================================================================

							by JCarter426

================================================================================
    TABLE OF CONTENTS
================================================================================

1.  Summary
2.  Installation
3.  Uninstallation
4.  Compatibility & Other Notes
5.  Credits
6.  Permissions
7.  Disclaimers
8.  Donations
9.  Contact



================================================================================
1.  SUMMARY
================================================================================

This mod adds a Trandoshan named Garassk who will tailor robes for the player
and Jedi party members. He can change the color of your robes to any of four
options: brown, black, red, and blue. The items retain their stats, with only
the appearance of the robes changed.

The tailor also runs a clothing store with infinite amounts of some generic
outfits, plus a select set of armor, gloves, belts, and headgear in smaller
amounts. Some of the armor he sells is new; files for the items already existed,
but they were inaccessible in the regular game.

I've also given Garassk an extensive dialogue tree, so you can ask him the usual
questions about the planet, and he will react to certain quest states.

To start, Garassk may be found in the hangar of the Jedi enclave on Dantooine.
Later in the game, he moves to Anchorhead on Tatooine, down the street from the
Czerka office.

You will need to start a new game or load a save from before you first arrive on
Dantooine for the mod to take effect.



================================================================================
2.  INSTALLATION
================================================================================

1. Run Jedi_Tailor_K1.exe.
3. Select "Basic Installation".
2. Click "Install Mod" and select your game directory (default name SWKOTOR).
4. Optionally, run the installer again if you want to install the 100% Brown
   compatibility patch.



================================================================================
3.  UNINSTALLATION
================================================================================

1. Remove the installed files or replace from backups if necessary.



================================================================================
4.  COMPATIBILITY
================================================================================

This mod patches the modules danm13 and tat_m17aa and may not be compatible with
other mods that affect those areas.

This mod includes an icon fix from my Mandalorian Armor mod. If you use both
mods, or some other mod that fixes that icon, then you can ignore the warning
about that file being skipped.

This mod is compatible with my Robe Adjustment mod, allowing you to change the
color of the Apprentice Robes, but you must update the Robe Adjustment mod to
version 1.1 or later.

This mod is compatible with my Cloaked Jedi Robes, Cloaked Hybrid Robes, and
Cloaked Party Robes mods and includes a compatibility patch for the 100% Brown
color option of those mods. It adjusts the tailor's dialogue to make all
references to robe color consistent with the brown shades in that option (brown,
black, buff, and grey).

The tailor will only recognize the original game robe items plus the variants
the mod adds in the four standard colors. This mod may be compatible with other
mods that add new robe items, but the tailor will only be able to swap around
the old kinds.

The tailor will only perform for the player and standard Jedi party members
(Bastila, Jolee, and Juhani).



================================================================================
6.  CREDITS
================================================================================

KOTOR Tool		Fred Tetra
TSL Patcher		stoffe
			with updates by Fair Strides
CSLU Toolkit		Center for Spoken Language Understanding
			license courtesy Jenko Jenks
DeNCS			JdNoa & Dashus
DLGEditor		tk102
ERFEdit			stoffe
			with updates by Fair Strides
K-GFF			tk102
LipSynchEditor		JdNoa
NWNSSCOMP		Torlack, stoffe, & tk102



================================================================================
5.  PERMISSIONS
================================================================================

I hereby grant nobody except myself permission to upload some or all of this mod
anywhere for any reason. For any reason.

If you would like to include any part of this mod in anything, then please
contact me for permission.



================================================================================
7.  DISCLAIMERS
================================================================================

OBSIDIAN IS THE NEW BLACK. DON'T WEAR BIOWARE AFTER LABOR DAY.



================================================================================
8.  DONATIONS
================================================================================

If you enjoy my mods and would like to show your support in a monetary manner,
you may do so via PayPal with the donation link below.

http://www.paypal.me/carterunited

For various legal and ethical reasons, this is entirely optional and is not a
requirement to downloading or using any of my mods. I also do not create
specific mods for hire.

I make mods as a hobby and will most likely do so regardless of any donations or
lack thereof, but modding does take up a lot of my time and every bit helps.



================================================================================
9.  CONTACT
================================================================================

Questions? Problems? Suggestions? Something else?

Email me at kotor.hexATgmailDOTcom or PM me on Deadly Stream or wherever else
you can find me.