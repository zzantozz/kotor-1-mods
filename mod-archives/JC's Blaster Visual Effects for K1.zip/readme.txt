================================================================================

		JC's Blaster Visual Effects for K1		v1.0

================================================================================

								by JCarter426

================================================================================
    TABLE OF CONTENTS
================================================================================

1.  Summary
2.  Installation
3.  Uninstallation
4.  Compatibility
5.  Credits
6.  Distributing and Including This Mod
7.  Disclaimers
8.  Contact



================================================================================
1.  SUMMARY
================================================================================

This mod changes the visual effects for all the laser blasts in the game. Energy
blasters, ion blasters, disruptors, bowcasters - I've replaced them all. Except
sonic, because really, sonic?

In general, I've added more detail and made them match what's depicted on film
as best as I could, when there was a visual reference. I took screenshots of
the movies and got out my eyedropper tool and everything. The cores of the
lasers are brighter so they look more like lasers, instead of having the whole
thing as one flat color. I also messed around with light objects so each laser
will illuminate surrounding objects in the appropriate color.

For disruptors, I've included three color options: white, green, and yellow. The
default install is white, like the original, and the other two are included
as optional things.



================================================================================
2.  INSTALLATION
================================================================================

1. Copy the files from Override to your own Override folder (if you don't have
   one, make one).

2. Optionally, copy a set of files from the Optional folder to your Override
   folder. Overwrite the previously installed files when asked. These will make
   the disruptor blasts either yellow or green rather than the default white,
   depending on what you choose.



================================================================================
3.  UNINSTALLATION
================================================================================

1. Delete the installed files.



================================================================================
4.  COMPATIBILITY
================================================================================

This mod is not compatible with any mods that alter the laser visual effects for 
energy blasters, ion blasters, disruptors, or bowcasters. It is compatible with
any mods that alter the models of these weapons, however. This only affects the
lasers.



================================================================================
5.  CREDITS
================================================================================

KOTOR Tool		Fred Tetra
MDLEdit			bead-v



================================================================================
6.  DISTRIBUTING AND INCLUDING THIS MOD
================================================================================

I hereby grant nobody except myself permission to upload some or all of this mod
anywhere for any reason.

If you would like to include any part of this mod in anything, then please
contact me for permission.



================================================================================
7.  DISCLAIMERS
================================================================================

IT'S SO DENSE, EVERY SINGLE IMAGE HAS SO MANY THINGS GOING ON...



================================================================================
8. CONTACT
================================================================================

Questions? Problems? Suggestions? Something else?

Email me at kotor.hexATgmailDOTcom or PM me on Deadly Stream or wherever else 
you can find me.