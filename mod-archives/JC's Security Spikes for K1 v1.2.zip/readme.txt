================================================================================

		JC's Security Spikes for K1			v1.2

================================================================================

								by JCarter426

================================================================================
    TABLE OF CONTENTS
================================================================================

1.  Summary
2.  Installation
3.  Uninstallation
4.  Credits
5.  Permissions
6.  Disclaimers
7.  Contact



================================================================================
1.  SUMMARY
================================================================================

Security spikes are disposable items that give the player a temporary boost to
their Security skill when activated, helping them pick more difficult locks. At
least, that's how it's supposed to be. That's how they work on the Xbox version,
and in KOTOR 2, but security spikes don't actually do anything at all on the PC
version of KOTOR 1.

The cause seems to be some sort of bug in the GUI that prevents security spikes
from ever appearing in their intended slot. So when interacting with a door,
there isn't an option to scroll from the Security skill to security spikes, as
there is in KOTOR 2. The GUI was changed for the port from Xbox to PC, and
security spikes probably got left out due to oversight. I couldn't find any way
to resolve the issue, though, so I came up with two alternative options.

OPTION A

Option A replicates the security spikes' intended function as best as I could
manage. They�ve been given an activate item property and appear in the non-
medical item slot (along with stimulants and shields).

When a character activates a security spike, they receive a temporary boost to
their Security skill and proceed to unlock the nearest door or container. Apart
from the boost, the skill check for the lock is the same as usual: 1d20 +
Security vs. the lock�s DC. Security spikes are single-use and discarded whether
the character succeeds in picking the lock or not; however, they are not used up
if the attempt was impossible � if there wasn�t anything in range or the lock
required a special keycard, for example. Regular security tunnelers grant a +5
bonus and security spike tunnelers grant a +10 bonus.

OPTION B

Option B removes security spikes from the game, replacing them with credits. The
value is equivalent to the most you could get from selling the original security
spike items to a merchant. Mission�s ability to create security spikes on the
Ebon Hawk is removed.



================================================================================
2.  INSTALLATION
================================================================================

1. Run Security_Spikes_K1.exe.
2. Select which option you want to install (A or B).
3. Click "Install Mod" and select your game directory (default name SWKOTOR).



================================================================================
3.  UNINSTALLATION
================================================================================

1. Remove all installed files. Replace k_hmis_dialog.dlg with backup if
   necessary.


================================================================================
4.  CREDITS
================================================================================

KOTOR Tool		Fred Tetra
K-GFF & DLGEditor	tk102
TSLPatcher		stoffe
NWNSSCOMP		Torlack, stoffe, & tk102



================================================================================
5.  PERMISSIONS
================================================================================

I hereby grant nobody except myself permission to upload some or all of this mod
anywhere for any reason. For any reason.

If you would like to include any part of this mod in anything, then please
contact me for permission.



================================================================================
6.  DISCLAIMERS
================================================================================

Items like Security Spikes add a bonus to your Security skill. Use these to help
open difficult locks and GOOD LUCK FINDING THEM IN THE GUI HA-HA-HA-HA-HA.



================================================================================
7.  CONTACT
================================================================================

Questions? Problems? Suggestions? Something else?

Email me at kotor.hexATgmailDOTcom or PM me on Deadly Stream or wherever else 
you can find me.