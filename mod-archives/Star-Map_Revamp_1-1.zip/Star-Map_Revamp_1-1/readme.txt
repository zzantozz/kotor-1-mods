///// Knights of the Old Republic: Star Map Revamp /////
Author: CarthOnasty
Version: 1.1
Contact: Find me on http://deadlystream.com.

///// 01. Background /////

Being such a main part of the K1 story, I was surprised to see these had yet to be revamped. I was looking to get into modding/reskinning, so I thought this would be a great project.


///// 02. Enhancements /////

-First steps were to update the overall model. I wanted some visual upgrades while still maintaining a very-aged and neglected structure. I love the runes scattered throughout the game and I really wanted to incorporate those as well. It seemed fitting to light them. (And you're going to them all over the place.) 
-Next section was so focus on the HUD (for lack of a better term). It was very pixelated and really needed a crisp, new look. I tried to simplify it a bit and ended up removing a couple of parts as well. The biggest change I made was creating a new piece for the planet locators. I simply didn't like the originals and wanted to make the location an actual planet. 
-This was a really fun part--recreating the central galaxy this all revolved around. I used some shots of actual galaxies, nebulas, and starfields. It's hard to beat the real thing. I adjusted the colors slightly for better clarity as well. 
-The mother of a bastard that caused me the most grief, was the dodecahedron in the center of the star map. The texture had such a bizarre repeat pattern and never really wrapped that well. I'm happy to the point I got it to, but would like to make that an actual sphere in v2.


///// 03. Future Plans /////

-In thinking about a version 2, I'd like to actually edit the model files. I think some edges could be softened, but mostly I'd like to adjust the mapping to avoid so many repeated areas of the texture.

-The final opening of the star map, where the PC finds out the location of the forge could use some work. Most (if not all) is model work and I wasn't ready for that. 
-I’d also like to adjust the lighting in a couple of places. Would I go as far as to customize it for every zone you find a map? I dunno, that's a big endeavor and there are a limited number of placeables.


///// 04. Moving Forward /////

This has been a fun project for sure, and I'm happy to see it come to fruition. Please download and let me know your thoughts. I open to constructive criticism and whatever I can do to the better the project, I'm happy to do so.


///// 05. Install /////

Drag 'em to your override folder. These shouldn't conflict with anything.


///// 06. Uninstall /////

Remove the files.


///// 07. Disclaimer /////

Distribute, have fun, edit, whatever. I only ask that you don't claim this as your own.


///// 08. Thanks /////

So many! Shout outs for tutorials, advice, suggestions, testing, encouragement, and more. A Future Pilot, Darth_Sapiens, DarthParametric, DarthVarkor, djh269, InSidious, JCarter426, Kexikus, ndix UR, Rece, Sith Holocron, Sithspecter, Sniggles, tjsase, VarsityPuppet, Zhaboka