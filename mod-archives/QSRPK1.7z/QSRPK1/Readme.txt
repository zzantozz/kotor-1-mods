Quarterstaff Replacement Pack for K1
A Mod for Star Wars Knights of The Old Republic
Author: N-DReW25
1.0.0 Release Date: 04.01.2023


Installation:
Copy & Paste the files inside the "For Override" folder and place them into the "Override" folder inside your "swkotor" directory.


Description:
Since the 2010s, there have been many attempts at creating high quality models and textures for the weapons found in the Kotor games, however, there are several types of weapons which don't have
any HD mods in 2023: Gamorrean Battleaxes, Stun Batons and Quarterstaffs.

But some of you might recall DeadMan's Quarterstaff Replacement Pack from 2012 which replaced the Quarterstaff models with high quality models and textures... this mod was made for Kotor 2 though
and was never ported for K1 players to enjoy... until now!

10 years after the release of the original, the Quarterstaff Replacement Pack has now been ported to K1 replacing the Quarterstaff and the Massassi Battle Staff.

Quarterstaffs can either be bought from merchants or wielded by NPCs as weapons (such as the Black Vulkars and Outcast NPCs on Taris)


Known Bugs:
This mod shouldn't have bugs but if there is Just PM me on Deadlystream.

It should be noted that the Massassi Battle Staff sometimes doesn't extend if equipped when the player is doing the "battle pose" animation. The weapon will be able to extend once this animation stops.


Incompatibilities:
Report any unknown incompatibilities to me on Deadlystream.com


Permissions:
You are free to use this models as you like as long as you give proper credit to DeadMan.
Under NO CIRCUMSTANCES CAN ASSETS OF THIS MOD TO BE UPLOADED TO STEAM WORKSHOP.

Special Thanks to:
DeadMan: For the original mod!
SithSpecter, RevanDark and AshuraDX: Assets used in the original mod by DeadMan!
Bioware: For such an amazing game!
Fred Tetra: For Kotor Tool!
Stoffee: For TSLPatcher!
Everyone who downloads the mod!


Legal:
THIS MODIFICATION IS NOT SUPPORTED BY BIOWARE/OBSIDIAN ENTERTAINMENT, LUCASARTS, DISNEY OR ANY LICENSERS/SPONSORS OF THE MENTIONED COMPANIES. USE OF THIS FILE IS AT YOUR OWN RISK AND THE ABOVE-MENTIONED COMPANIES OR THE AUTHOR IS NOT RESPONSIBLE FOR ANY DAMAGE CAUSED TO YOUR COMPUTER FOR THE USAGE OF THIS FILE.