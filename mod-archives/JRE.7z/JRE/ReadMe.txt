=========================================================================
[JRE]
by Kexikus
=========================================================================

About:
As the title suggests, this mod improves the [CENSORED] romance in K1. To do so, it does two things: First of all, the final conversation is now triggered automatically if available in order not to get lost. Secondly, it now includes a kiss, similar to the one in the [CENSORED] (actually, I used the same animations).

Installation:
Simply let TSL Patcher do its magic. It should find your KotOR installation automatically. If it doesn't and you have to select it manually, choose the folder that includes swkotor.exe. Do NOT delete the backup folder that is created during the installation, you'll need it if you ever want to uninstall this mod.
For modders: I included the source scripts in the download in case you're interested. Ignore them if you only want to install and play the mod.

Uninstallation:
Delete jre_dialog.dlg, jre_intro.ncs, jre_kiss.ncs, jre_trigger.ncs and jre_trigger.utt from your Override folder. Then find the backup of unk_m44ac.mod created during the installation of this mod (it is located in the backup folder that was created in the folder where you ran TSLPatcher.exe) and copy it into the Modules folder of your KotOR installation, replacing the one already there. Note however, that this might screw up other mods that modified the same file and were installed afterwards!

Compabilitiy:
Thanks to TSLPatcher this mod is compatible pretty much everything. (The only incompability I can think of would be another mods that adds cameras with the same IDs but that's pretty unlikely.)

Changelog:
1.0 Initial release

Credits:
Mod by Kexikus
swfan28 for the kiss animation idea
Fair Strides for the trigger script frame
TSL Patcher by stoffe

THIS MOD IS NOT SUPPORTED BY LUCASARTS OR BIOWARE. USE THIS FILE AT YOUR OWN RISK. NEITHER THE AUTHOR OF THIS MOD NOR THE COMPANIES MENTIONED ABOVE ARE RESPONSIBLE FOR ANY DAMAGE TO YOUR COMPUTER WHEN USING THIS FILE.
