ANIMATED CANTINA SIGN FOR KOTOR 1
=================================
 
MOD AUTHOR: Sith Holocron
ORIGINAL RELEASE DATE: 18 JUL 2017

GAMES: Star Wars Knights of the Old Republic 


Description:
------------

Remember my "NPC Portraits for KotOR 1" mod?  I used this little animated texture for the background of Mission's portrait.  This is a minimal effort mod but if you want it, it's yours to use.  (If you wanted to use this in TSL, you would have to rename both the TGa and the TXI file to "TEL_BBrds4".)



Installation:
-------------
Put the TGA file and TXI file into your Override folder.



Uninstall:
----------
Remove the TGA file and TXI file from the Override folder.



Enjoy!


Legal Disclaimer:
-------------------
 
All materials and copyrights belong to LucasArts, Bioware and Obsidian Entertainment Inc. I own none of the materials, and I'm not making any money out of this mod. It is to be distributed as-is without alteration, unless by permission of me. This mod is not to be distributed for profit, either.

I hereby state that I specifically do NOT wish this mod to be uploaded to Steam Workshop. I may release this on NexusMods at a later date but I don't wish others to do so. Usage in other mods must be requested AND approved by me before your use.

