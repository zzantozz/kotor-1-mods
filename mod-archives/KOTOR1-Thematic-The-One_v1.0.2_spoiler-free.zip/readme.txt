See the Deadlystream mod page for details about the nature of the mod.


Installation
When you are ready, click the Install Mod button in the bottom right corner of this screen. This will give you a new window; in that window, select your game directory (default name SWKotOR) and install.


Permissions
As with any mod “I” have made or will make in the future, this mod has completely open permissions: modify it, redistribute it, reupload it, do whatever. So long as you give me credit for the idea and for the balance settings if you choose to retain most of mine, go for it. You don’t even need to ask me.


================================================================================
CREDITS
================================================================================

JC	       He made this entire mod and said it would be funnier if I uploaded it instead of him
KOTOR Tool     Fred Tetra
TSL Patcher    stoffe & Fair Strides
DeNCS          JdNoa & Dashus
ERFEdit        stoffe & Fair Strides
K-GFF          tk102
NWNSSCOMP      Torlack, stoffe, & tk102
xoreos tools   xoreos team (https://xoreos.org/)