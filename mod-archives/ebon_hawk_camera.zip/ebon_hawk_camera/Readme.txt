***********************************
Knights of the Old Republic 
***********************************
TITLE: Ebon Hawk Camera Replacement
AUTHOR: LDR

FILENAME: ebon_hawk_camera
FILESIZE: 3 KB

--------------------------
INSTALLATION INSTRUCTIONS
--------------------------
Simply put the 2da file and the vis file into the Override folder in the KotOR directory.

To uninstall, remove the 2da file and the vis file from the Override folder in the KotOR directory.

------------
Permissions
------------
You may not use any assets of this mod in your own mod without first contacting me (and Darth Parametric). 

------------
DESCRIPTION
------------
Changes the Ebon Hawk camera to where it reduces the zoom on the player, akin to the "default" camera.

-----
BUGS
-----
None I hope. If you find any please post them in the comments. I will address them as soon as I can.

--------------
COMPATABILITY
--------------
So long as there isn't another mod that makes edits to the camerastyle.2da or m12aa.vis, there shouldn't be any mod conflicts with K1R or any other KotOR 1 mod.

Note: there will be a hard incompatibility with any other mod that edits the m12aa.vis file. It can only be resolved with manual merging, since TSLPatcher doesn't allow for dynamic patching of VIS files (or LYTs). 

-------
Credits
-------
Darth Parametric for his m12aa.vis file that fixed an issue where some Ebon Hawk rooms weren't visible due to the increased camera radius.

Fred Tetra for his very useful KotOR Tool.

Fair Strides.

All of you who downloaded this mod! Thank You!

